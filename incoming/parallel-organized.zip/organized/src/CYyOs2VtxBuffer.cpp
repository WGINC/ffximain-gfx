// CYyOs2VtxBuffer.cpp -- source unit CYyOs2VtxBuffer. Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: stores CYyOs2VtxBuffer_vtbl into this (ctor/dtor) (was in gfx_free_002.cpp)
// FUNCTION: FFXIMAIN 0x1002D680
// GATE: PASS -- 100 trials, 100 returned normally, 100 D3D calls compared (diffemu_gfx, clean build)
XI_API int __thiscall fn_1002D680(int self_, _DWORD **a2)
{
  _DWORD *v3;
  orig::sub_10074740((_DWORD *)self_);
  *(_DWORD *)self_ = &CYyOs2VtxBuffer_vtbl;
  *(_DWORD *)(self_ + 56) = 0;
  *(_DWORD *)(self_ + 52) = a2;
  if ( a2 != nullptr )
    v3 = *a2;
  else
    v3 = nullptr;
  orig::sub_10071F50(v3);
  *(_DWORD *)(self_ + 92) = 0;
  *(_DWORD *)(self_ + 96) = 0;
  *(_DWORD *)(self_ + 64) = 0;
  *(_DWORD *)(self_ + 68) = 0;
  *(_DWORD *)(self_ + 72) = 0;
  *(_DWORD *)(self_ + 76) = 0;
  *(_DWORD *)(self_ + 80) = 0;
  *(_DWORD *)(self_ + 84) = 0;
  *(_DWORD *)(self_ + 88) = 0;
  g_pCDx->pDevice->CreateVertexShader(&g_vsDecl_1628, nullptr, (void *)(self_ + 100), 0);
  *(_BYTE *)(self_ + 104) = 0;
  *(_BYTE *)(self_ + 105) = 0;
  *(_DWORD *)(self_ + 106) = 0;
  *(_DWORD *)(self_ + 110) = 0;
  *(_DWORD *)(self_ + 114) = 0;
  *(_DWORD *)(self_ + 118) = 0;
  *(_DWORD *)(self_ + 122) = 0;
  return self_;
}

// PLACED: stores CYyOs2VtxBuffer_vtbl into this (ctor/dtor) (was in gfx_free_002.cpp)
// FUNCTION: FFXIMAIN 0x1002D700
// GATE: PASS -- 100 trials, 26 returned normally, 22 D3D calls compared (diffemu_gfx, clean build)
XI_API char __thiscall fn_1002D700(int self_)
{
  int v2;
  int v3;
  unsigned int v4;
  int v5;
  int v6;
  int i;
  v2 = *(_DWORD *)(self_ + 92);
  *(_DWORD *)self_ = &CYyOs2VtxBuffer_vtbl;
  if ( v2 != 0 )
  {
    orig::sub_10028700(v2);
    *(_DWORD *)(self_ + 92) = 0;
  }
  v3 = *(_DWORD *)(self_ + 64);
  *(_DWORD *)(self_ + 96) = 0;
  if ( v3 != 0 )
  {
    (*(void (__stdcall **)(int))(*(_DWORD *)v3 + 8))(v3);
    *(_DWORD *)(self_ + 64) = 0;
  }
  if ( *(_DWORD *)(self_ + 76) != 0 )
  {
    orig::sub_1003B3C0((_DWORD *)(self_ + 76));
    *(_DWORD *)(self_ + 76) = 0;
  }
  v4 = *(_DWORD *)(self_ + 100);
  *(_DWORD *)(self_ + 68) = 0;
  *(_DWORD *)(self_ + 72) = 0;
  *(_DWORD *)(self_ + 80) = 0;
  *(_DWORD *)(self_ + 84) = 0;
  *(_DWORD *)(self_ + 88) = 0;
  if ( v4 != 0 )
  {
    g_pCDx->pDevice->DeleteVertexShader(v4);
    *(_DWORD *)(self_ + 100) = 0;
  }
  v5 = *(_DWORD *)(self_ + 106);
  *(_BYTE *)(self_ + 104) = 0;
  *(_BYTE *)(self_ + 105) = 0;
  if ( v5 != 0 )
  {
    orig::sub_10028700(v5);
    *(_DWORD *)(self_ + 106) = 0;
  }
  v6 = *(_DWORD *)(self_ + 114);
  *(_DWORD *)(self_ + 110) = 0;
  if ( v6 != 0 )
  {
    orig::sub_10028700(v6);
    *(_DWORD *)(self_ + 114) = 0;
  }
  *(_DWORD *)(self_ + 118) = 0;
  for ( i = 0; i < 16; ++i )
  {
    if ( dword_1045B650[i] == self_ )
      break;
  }
  if ( i != 16 )
    dword_1045B650[i] = 0;
  if ( *(_DWORD *)(self_ + 122) != 0 )
  {
    orig::sub_10028700(*(_DWORD *)(self_ + 122));
    *(_DWORD *)(self_ + 122) = 0;
  }
  return orig::sub_100747C0((_DWORD *)self_);
}

