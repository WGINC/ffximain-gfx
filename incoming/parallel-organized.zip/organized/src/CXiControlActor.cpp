// CXiControlActor.cpp -- source unit CXiControlActor. Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: between 0x100a8d60 (name CXiControlActor_IsMovingTechnic) and 0x100a9230 (name CXiControlActor_UseMagic_SchStatus), both within 4 KB (was in gfx_free_00A.cpp)
// FUNCTION: FFXIMAIN 0x100A8E10
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API char ** __cdecl CMoTask_GetRuntimeClass_variant17(void)
{
  return &CMoTask_classdesc;
}

