// sqsnScene.cpp -- original source: sqsnScene.c (dancer middleware, C). Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: sqsnSceneDraw (PS2 name, scene functions) (was in gfx_free_028.cpp)
// FUNCTION: FFXIMAIN 0x1028F8C0
// GATE: PASS -- 100 trials, 5 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API void __cdecl fn_1028F8C0(int a1)
{
  int v2;
  int v3;
  int v4;
  int v5;
  int v6;
  int v7;
  int v8;
  int v9;
  int v10;
  int v11;
  int v12;
  int v13;
  int v14;
  int v15;
  int v16;
  int v17;
  void (*v18)(void);
  __int16 v19; // fps
  double v20;
  bool v21; // c0
  char v22; // c2
  bool v23; // c3
  __int16 v24; // fps
  double v25;
  bool v26; // c0
  char v27; // c2
  bool v28; // c3
  void (*v29)(void);
  int v30;
  int v31;
  int v32;
  int v33;
  int v34;
  int v35;
  int v36;
  int v37;
  int v38;
  float *v39;
  v2 = 0;
  v3 = 0;
  v32 = 0;
  v31 = 0;
  if ( *(_DWORD *)(a1 + sqsnScene_numCameras) != 0 )
  {
    v4 = 0;
    v5 = *(_DWORD *)(a1 + sqsnScene_numLayers);
    v39 = *(float **)(*(_DWORD *)(a1 + sqsnScene_cameras) + sqsnSceneCamera_size * *(_DWORD *)(a1 + sqsnScene_idCamera));
    if ( v5 > 0 )
    {
      do
      {
        if ( *(_BYTE *)(*(_DWORD *)(a1 + sqsnScene_layers) + v2 + sqsnLayer_sort) != 0 )
          orig::sqsnSceneLayerSort(a1, v4);
        ++v4;
        v2 += sqsnLayer_size;
      }
      while ( v4 < *(_DWORD *)(a1 + sqsnScene_numLayers) );
    }
    if ( *(int *)(a1 + sqsnScene_numLayers) > 0 )
    {
      v6 = *(_DWORD *)(a1 + sqsnScene_layers);
      v7 = *(_DWORD *)(a1 + sqsnScene_numLayers);
      do
      {
        if ( *(float *)v6 != 0.0 && *(_BYTE *)(v6 + sqsnLayer_visible) != 0 )
          ++v3;
        v6 += sqsnLayer_size;
        --v7;
      }
      while ( v7 != 0 );
      v31 = v3;
      if ( v3 > 0 )
      {
        v8 = g_sceneRT[0];
        if ( g_sceneRT[0] == 0 )
        {
          v8 = orig::sqgxTextureAdd(1024, 512, 3, nullptr);
          g_sceneRT[0] = v8;
        }
        orig::sqgxTextureDraw(v8, 1);
        orig::sqgxTextureClear((float *)(g_pSqgxContext + sqgxContext_BGColor), 1);
        if ( v3 > 1 )
        {
          v9 = g_sceneRT1;
          if ( g_sceneRT1 == 0 )
          {
            v9 = orig::sqgxTextureAdd(1024, 512, 3, nullptr);
            g_sceneRT1 = v9;
          }
          orig::sqgxTextureDraw(v9, 1);
          orig::sqgxTextureClear((float *)(g_pSqgxContext + sqgxContext_BGColor), 1);
        }
      }
    }
    v10 = 0;
    v11 = 0;
    if ( *(int *)(a1 + sqsnScene_numLayers) > 0 )
    {
      v12 = 0;
      do
      {
        v13 = v12 + *(_DWORD *)(a1 + sqsnScene_layers);
        if ( *(_BYTE *)(v13 + sqsnLayer_visible) != 0 && *(float *)v13 != 0.0 )
        {
          --v31;
          orig::sqgxTextureDraw(g_sceneRT[v10], 1);
          orig::sqrdCamera_Apply(v39);
          orig::sqgxMatrixCamera(*(_DWORD **)(*(_DWORD *)(a1 + sqsnScene_cameras) + sqsnSceneCamera_size * *(_DWORD *)(a1 + sqsnScene_idCamera) + sqsnSceneCamera_mat));
          if ( *(_BYTE *)(a1 + sqsnScene_shadowOn) != 0 && *(_DWORD *)(a1 + sqsnScene_numShadows) != 0 )
            orig::sqsnSceneLayerDrawShadowed((_DWORD *)a1, v11);
          else
            orig::sqsnSceneLayerDraw((_DWORD *)a1, v11);
          orig::sqgxTextureSet(g_sceneRT[v10]);
          v10 = 1 - v10;
          if ( v31 != 0 )
          {
            orig::sqgxTextureDraw(g_sceneRT[v10], 1);
          }
          else
          {
            orig::sqgxTextureDraw(*(_DWORD *)(g_pSqgxContext + sqgxContext_defaultDrawBuf), 1);
            orig::sqgxTextureClear((float *)(g_pSqgxContext + sqgxContext_BGColor), 1);
          }
          orig::sqsnSceneLayerSnapShotComposite(a1, v11);
        }
        ++v11;
        v12 += sqsnLayer_size;
      }
      while ( v11 < *(_DWORD *)(a1 + sqsnScene_numLayers) );
    }
    orig::sqrdCamera_Apply(v39);
    orig::sqgxMatrixCamera(*(_DWORD **)(*(_DWORD *)(a1 + sqsnScene_cameras) + sqsnSceneCamera_size * *(_DWORD *)(a1 + sqsnScene_idCamera) + sqsnSceneCamera_mat));
    if ( *(float *)(a1 + sqsnScene_fadeValue) < 1.0 )
    {
      orig::sqgxTextureGetSize(*(_DWORD *)(g_pSqgxContext + sqgxContext_defaultDrawBuf), &v34, &v33);
      v14 = g_sceneFadeMaskRT;
      if ( g_sceneFadeMaskRT == -1 )
      {
        v14 = orig::sqgxTextureAdd(v34, v33, 4, nullptr);
        g_sceneFadeMaskRT = v14;
      }
      v32 = *(_DWORD *)(g_pSqgxContext + sqgxContext_defaultDrawBuf);
      orig::sqgxTextureDraw(v14, 1);
      g_pDancerDevice->SetRenderState(D3DRS_STENCILENABLE, TRUE);
      v35 = 0;
      v36 = 0;
      v37 = 0;
      v38 = 0;
      orig::sqgxTextureClear((float *)&v35, 1);
      orig::sqgxTextureStencilClear(0);
      g_pDancerDevice->SetRenderState(D3DRS_STENCILPASS, D3DSTENCILOP_INCR);
      g_pDancerDevice->SetRenderState(D3DRS_STENCILFUNC, D3DCMP_ALWAYS);
      orig::sqgxTextureDecal(1);
      orig::sqgxTextureClamp(1);
      orig::sqgxBlendOff();
      orig::sqgxZTest(0);
      orig::sqgxZTest(1);
      orig::sqgxBlendOff();
    }
    v15 = 0;
    if ( *(int *)(a1 + sqsnScene_numLayers) > 0 )
    {
      v16 = 0;
      while ( 1 )
      {
        v17 = *(_DWORD *)(a1 + sqsnScene_layers) + v16;
        if ( *(float *)v17 == 0.0 && *(_BYTE *)(v17 + sqsnLayer_visible) != 0 )
          break;
LABEL_53:
        ++v15;
        v16 += sqsnLayer_size;
        if ( v15 >= *(_DWORD *)(a1 + sqsnScene_numLayers) )
          goto LABEL_54;
      }
      v18 = *(void (**)(void))(v17 + sqsnLayer_preDraw);
      if ( v18 != nullptr )
        v18();
      if ( *(_BYTE *)(a1 + sqsnScene_shadowOn) != 0 && *(_DWORD *)(a1 + sqsnScene_numShadows) != 0 )
      {
        if ( *(float *)(*(_DWORD *)(a1 + sqsnScene_layers) + v16 + sqsnLayer_fadeValue) < 1.0 )
        {
          v20 = *(float *)(a1 + sqsnScene_fadeValue);
          v21 = v20 < 0.999;
          v22 = 0;
          v23 = v20 == 0.999;
          if ( (v19 & 0x4100) == 0 )
          {
LABEL_46:
            orig::nullsub_60(a1, v15);
            goto LABEL_51;
          }
        }
        orig::sqsnSceneLayerDrawShadowed((_DWORD *)a1, v15);
      }
      else
      {
        if ( *(float *)(*(_DWORD *)(a1 + sqsnScene_layers) + v16 + sqsnLayer_fadeValue) < 1.0 )
        {
          v25 = *(float *)(a1 + sqsnScene_fadeValue);
          v26 = v25 < 0.999;
          v27 = 0;
          v28 = v25 == 0.999;
          if ( (v24 & 0x4100) == 0 )
            goto LABEL_46;
        }
        orig::sqsnSceneLayerDraw((_DWORD *)a1, v15);
      }
LABEL_51:
      v29 = *(void (**)(void))(*(_DWORD *)(a1 + sqsnScene_layers) + v16 + sqsnLayer_postDraw);
      if ( v29 != nullptr )
        v29();
      goto LABEL_53;
    }
LABEL_54:
    if ( *(float *)(a1 + sqsnScene_fadeValue) < 1.0 )
    {
      orig::sqgxTextureSet(g_sceneFadeMaskRT);
      orig::sqgxTextureDraw(v32, 1);
      v30 = *(_DWORD *)(a1 + sqsnScene_fadeValue);
      v35 = 1065353216;
      v36 = 1065353216;
      v37 = 1065353216;
      v38 = v30;
      orig::sqgxColor(&v35);
      orig::sqgxBlendTrsp_Candidate();
      orig::sqgxTextureDecal(2);
      orig::sqgxTextureClamp(1);
      orig::sqgxZTest(0);
      g_pDancerDevice->SetRenderState(D3DRS_STENCILREF, 0);
      g_pDancerDevice->SetRenderState(D3DRS_STENCILFUNC, D3DCMP_LESS);
      orig::sqgx_DrawRect_Candidate(0, 0, v34, v33, 0, 0, v34, v33, 0);
      g_pDancerDevice->SetRenderState(D3DRS_STENCILENABLE, FALSE);
      orig::sqgxZTest(1);
      orig::sqgxBlendOff();
    }
  }
}

