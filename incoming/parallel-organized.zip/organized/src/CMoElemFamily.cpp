// CMoElemFamily.cpp -- source unit CMoElemFamily. Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: name CMoElemFamily_IsKind0 (was in gfx_free_004.cpp)
// FUNCTION: FFXIMAIN 0x10041120
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API BOOL __stdcall CMoElemFamily_IsKind0(int a1)
{
  return a1 == 0;
}

// PLACED: name CMoElemFamily_SharedCleanup (was in gfx_free_004.cpp)
// FUNCTION: FFXIMAIN 0x10044970
// GATE: PASS -- 100 trials, 6 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API char __thiscall CMoElemFamily_SharedCleanup(int *self_)
{
  int v2;
  int *v3;
  int v4;
  _DWORD **v5;
  _DWORD *v6;
  int v7;
  int *v8;
  int v9;
  *self_ = (int)&CMoElem_vtbl_ambiguous3;
  v2 = --g_countdown_1047BC6C;
  v3 = (int *)*(self_ + 63);
  if ( v3 != nullptr )
    v4 = *v3;
  else
    v4 = 0;
  v5 = (_DWORD **)*(self_ + 64);
  *(self_ + 63) = 0;
  if ( v5 == nullptr )
    v5 = (_DWORD **)*(self_ + 63);
  if ( v5 != nullptr )
    v6 = *v5;
  else
    v6 = nullptr;
  *(self_ + 64) = 0;
  if ( v6 != nullptr )
    orig::sub_100481D0(v6, (int)self_);
  if ( v4 != 0 )
  {
    orig::sub_10048140((_DWORD *)v4, (int)self_);
    orig::sub_10071EC0(v4, v7);
  }
  v8 = (int *)*(self_ + 89);
  if ( v8 != nullptr )
  {
    v9 = *v8;
    orig::sub_10071EC0(*v8, v2);
    *(_DWORD *)(v9 + 248) = 0;
    *(self_ + 89) = 0;
    if ( (*(_WORD *)(v9 + 24) & 0x7FFF) == 0 )
    {
      orig::sub_10073B20(*(int **)(v9 + 20));
      orig::sub_10074180((unsigned int *)g_pMeshResourceMng, *(unsigned int **)(v9 + 20));
    }
  }
  if ( v4 != 0 && (*(_BYTE *)(v4 + 26) & 4) != 0 && (*(_WORD *)(v4 + 24) & 0x7FFF) == 0 )
  {
    orig::sub_10073B20(*(int **)(v4 + 20));
    orig::sub_10074180((unsigned int *)g_pMeshResourceMng, *(unsigned int **)(v4 + 20));
  }
  if ( *(self_ + 66) != 0 )
  {
    orig::sub_1006C110(*(self_ + 66));
    *(self_ + 66) = 0;
  }
  orig::sub_1006C270((int *)((char *)self_ + 383));
  *self_ = (int)&CMoOtTask_vtbl_ambiguous1;
  orig::sub_10055250(self_ + 13);
  return orig::sub_100747C0(self_);
}

