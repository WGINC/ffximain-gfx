// CMoCelestial -- graphics members reconstructed from Hex-Rays output, gate-verified.
// Field names are offsets (field_XXX) unless noted; sizes come from the class descriptor.
#pragma once
#include "gfx_common.hpp"
#pragma pack(push, 1)
class XI_API CMoCelestial {
public:
    _DWORD * ScalarDeletingDtor(char a2);  // 0x1003D960

    void **vftable;  // +0x0
};
#pragma pack(pop)
static_assert(sizeof(CMoCelestial) == 0x4, "CMoCelestial: sizeof");
