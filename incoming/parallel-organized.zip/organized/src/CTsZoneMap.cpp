// CTsZoneMap.cpp -- source unit CTsZoneMap. Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: between 0x10177800 (name CTsZoneMap_LogZoneMetrics) and 0x10177d00 (stores CTsZoneMap_vtbl into this (ctor/dtor)), both within 4 KB (was in gfx_free_017.cpp)
// FUNCTION: FFXIMAIN 0x101779C0
// GATE: PASS -- 100 trials, 100 returned normally, 900 D3D calls compared (diffemu_gfx, clean build)
XI_API int __cdecl fn_101779C0(void)
{
  _DWORD v1[16];
  v1[0] = 1065353216;
  memset(&v1[1], 0, 16);
  v1[5] = 1065353216;
  memset(&v1[6], 0, 16);
  v1[10] = 1065353216;
  memset(&v1[11], 0, 16);
  v1[15] = 1065353216;
  orig::CDx_SetTransform(&g_pCDx->vftable, 256, v1);
  g_pCDx->pDevice->SetTexture(0, nullptr);
  g_pCDx->pDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
  g_pCDx->pDevice->SetVertexShader(322u);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_CURRENT);
  g_pCDx->pDevice->SetTextureStageState(1u, D3DTSS_COLOROP, D3DTOP_DISABLE);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_CURRENT);
  return g_pCDx->pDevice->SetTextureStageState(1u, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
}

// PLACED: between 0x10177800 (name CTsZoneMap_LogZoneMetrics) and 0x10177d00 (stores CTsZoneMap_vtbl into this (ctor/dtor)), both within 4 KB (was in gfx_free_017.cpp)
// FUNCTION: FFXIMAIN 0x10177B40
// GATE: PASS -- 100 trials, 100 returned normally, 46 D3D calls compared (diffemu_gfx, clean build)
XI_API int __cdecl fn_10177B40(float *a3, char a4, unsigned __int8 a5, unsigned __int8 a6, char a7, char a8)
{
  float v8;
  float v9;
  double v10;
  float v11;
  double v12;
  float v13;
  float v14;
  float v15;
  float v16;
  float v17;
  float v18;
  int result;
  float v20[24];
  float v21;
  float v22;
  float v23;
  float v24;
  v8 = a3[4];
  v9 = a3[5];
  v21 = *a3;
  v20[0] = v21;
  v10 = a3[1];
  v20[6] = v8;
  v11 = a3[6];
  v22 = v10;
  v20[1] = v10;
  v12 = a3[2];
  v20[7] = v9;
  v13 = a3[8];
  v20[8] = v11;
  v14 = a3[9];
  v20[12] = v13;
  v15 = a3[10];
  v20[13] = v14;
  v16 = a3[12];
  v20[14] = v15;
  v17 = a3[13];
  v18 = a3[14];
  v20[18] = v16;
  v20[20] = v18;
  BYTE1(v18) = a7;
  v20[19] = v17;
  LOBYTE(v18) = a4;
  v23 = v12;
  v20[2] = v12;
  LODWORD(v24) = a6 | ((a5 | (LOWORD(v18) << 8)) << 8);
  v20[21] = v24;
  v20[15] = v24;
  v20[9] = v24;
  v20[3] = v24;
  if ( a8 == 0 )
    g_pCDx->pDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_FALSE);
  result = orig::CDx_DrawPrimitiveUP(g_pCDx, 3, 4, (int)v20, 24);
  if ( a8 == 0 )
    return g_pCDx->pDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
  return result;
}

// PLACED: between 0x10177800 (name CTsZoneMap_LogZoneMetrics) and 0x10177d00 (stores CTsZoneMap_vtbl into this (ctor/dtor)), both within 4 KB (was in gfx_free_017.cpp)
// FUNCTION: FFXIMAIN 0x10177C50
// GATE: PASS -- 100 trials, 5 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API int __cdecl fn_10177C50(int a1, int a2, int a3, int a4, int a5, int a6)
{
  int v6;
  int v7;
  int v8;
  int v9;
  _DWORD v11[9];
  int v12;
  v6 = *(_DWORD *)(a1 + 4);
  v7 = *(_DWORD *)(a1 + 8);
  v11[0] = *(_DWORD *)a1;
  v11[2] = v7;
  v11[1] = v6;
  v8 = *(_DWORD *)(a2 + 4);
  v9 = *(_DWORD *)(a2 + 8);
  v11[6] = *(_DWORD *)a2;
  v11[8] = v9;
  BYTE1(v9) = a6;
  v11[7] = v8;
  LOBYTE(v9) = a3;
  v12 = (unsigned __int8)a5 | (((unsigned __int8)a4 | ((unsigned __int16)v9 << 8)) << 8);
  v11[3] = v12;
  return orig::CDx_DrawPrimitiveUP(g_pCDx, 2, 1, (int)v11, 24);
}

// PLACED: between 0x10177800 (name CTsZoneMap_LogZoneMetrics) and 0x10177d00 (stores CTsZoneMap_vtbl into this (ctor/dtor)), both within 4 KB (was in gfx_free_017.cpp)
// FUNCTION: FFXIMAIN 0x10177CD0
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API int __stdcall fn_10177CD0(float *a1, int a2, float a3)
{
  return orig::sub_10168D20((int)g_pCDx->pDevice, a1, a2, a3);
}

// PLACED: hand: operates on CTsZoneMap (was in gfx_free_017.cpp)
// FUNCTION: FFXIMAIN 0x10178070
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API char __thiscall fn_10178070(int self_)
{
  _DWORD *v2;
  int i;
  *(_DWORD *)self_ = &CTsZoneMap_vtbl;
  orig::ZoneMap_TeardownStep(self_);
  orig::ZoneMap_ReleaseStateBlock((unsigned int *)self_);
  if ( *(_DWORD *)(self_ + CTsZoneMap_vsHandleA) != 0 )
    g_pCDx->pDevice->DeleteVertexShader(*(_DWORD *)(self_ + CTsZoneMap_vsHandleA));
  if ( *(_DWORD *)(self_ + CTsZoneMap_vsHandleB) != 0 )
    g_pCDx->pDevice->DeleteVertexShader(*(_DWORD *)(self_ + CTsZoneMap_vsHandleB));
  if ( *(_DWORD *)(self_ + CTsZoneMap_vsHandles) != 0 )
    g_pCDx->pDevice->DeleteVertexShader(*(_DWORD *)(self_ + CTsZoneMap_vsHandles));
  if ( *(_DWORD *)(self_ + CTsZoneMap_vsHandles + 4) != 0 )
    g_pCDx->pDevice->DeleteVertexShader(*(_DWORD *)(self_ + CTsZoneMap_vsHandles + 4));
  if ( *(_DWORD *)(self_ + CTsZoneMap_vsHandles + 8) != 0 )
    g_pCDx->pDevice->DeleteVertexShader(*(_DWORD *)(self_ + CTsZoneMap_vsHandles + 8));
  if ( *(_DWORD *)(self_ + CTsZoneMap_vsHandles + 12) != 0 )
    g_pCDx->pDevice->DeleteVertexShader(*(_DWORD *)(self_ + CTsZoneMap_vsHandles + 12));
  if ( *(_DWORD *)(self_ + CTsZoneMap_vsHandles + 16) != 0 )
    g_pCDx->pDevice->DeleteVertexShader(*(_DWORD *)(self_ + CTsZoneMap_vsHandles + 16));
  if ( *(_DWORD *)(self_ + CTsZoneMap_psHandle) != 0 )
    g_pCDx->pDevice->DeletePixelShader(*(_DWORD *)(self_ + CTsZoneMap_psHandle));
  orig::sub_10055000((int **)(self_ + CTsZoneMap_subF));
  orig::ResetVtbl_10336614((_DWORD *)(self_ + CTsZoneMap_subE));
  orig::nullsub_1(self_ + CTsZoneMap_subD);
  orig::sub_10171920((_DWORD *)(self_ + CTsZoneMap_subC));
  orig::sub_101678D0((int *)(self_ + CTsZoneMap_subB));
  v2 = (_DWORD *)(self_ + CTsZoneMap_elemA + 2 * CTsZoneMap_elemA_stride + CTsZoneMap_elemA_sub);
  for ( i = 2; i != 0; --i )
  {
    v2 -= CTsZoneMap_elemA_stride / 4;
    orig::sub_1016FC80(v2);
  }
  return orig::sub_100747C0((_DWORD *)self_);
}

// PLACED: hand: operates on CTsZoneMap (was in gfx_free_017.cpp)
// FUNCTION: FFXIMAIN 0x101781D0
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API int __thiscall fn_101781D0(_DWORD *self_)
{
  int result;
  result = 0;
  g_zbiasZoneMesh = 0;
  g_zbiasPresetAux = 8;
  g_zbiasPreset_C4D0 = 15;
  g_zbiasOverlay = 15;
  g_zbiasRestore = 0;
  *(self_ + CTsZoneMap_field_3954C / 4) = 1065353216;
  if ( g_pCDx->isAtiAdapter != 0 )
  {
    g_zbiasZoneMesh = 0;
    g_zbiasPresetAux = 1;
    g_zbiasPreset_C4D0 = 2;
    g_zbiasOverlay = 2;
    g_zbiasRestore = 0;
    *(self_ + CTsZoneMap_field_3954C / 4) = 1065353216;
  }
  return result;
}

// PLACED: hand: operates on CTsZoneMap (was in gfx_free_017.cpp)
// FUNCTION: FFXIMAIN 0x10178B00
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API int __thiscall fn_10178B00(unsigned int *self_)
{
  unsigned int v2;
  int result;
  v2 = *(self_ + CTsZoneMap_stateBlock / 4);
  if ( v2 != -1 && v2 != 0 )
  {
    result = g_pCDx->pDevice->DeleteStateBlock(v2);
    *(self_ + CTsZoneMap_stateBlock / 4) = 0;
  }
  return result;
}

// PLACED: hand: operates on CTsZoneMap (was in gfx_free_017.cpp)
// FUNCTION: FFXIMAIN 0x101791F0
// GATE: PASS -- 100 trials, 100 returned normally, 600 D3D calls compared (diffemu_gfx, clean build)
XI_API int __thiscall fn_101791F0(void *self_)
{
  g_pCDx->pDevice->SetTexture(0, nullptr);
  g_pCDx->pDevice->SetVertexShader(*((_DWORD *)self_ + CTsZoneMap_vsHandleA / 4));
  g_pCDx->pDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
  g_pCDx->pDevice->SetStreamSource(0, (IDirect3DVertexBuffer8 *)g_boxPositionVB, 12u);
  g_pCDx->pDevice->SetStreamSource(1u, (IDirect3DVertexBuffer8 *)g_boxStream1VB, 24u);
  g_pCDx->pDevice->SetIndices((IDirect3DIndexBuffer8 *)g_boxIB, 0);
  return orig::CDx_DrawIndexedPrimitive(g_pCDx, 4, 0, 24, 0, 12);
}

// PLACED: hand: operates on CTsZoneMap (was in gfx_free_017.cpp)
// FUNCTION: FFXIMAIN 0x101792A0
// GATE: PASS -- 100 trials, 100 returned normally, 200 D3D calls compared (diffemu_gfx, clean build)
XI_API int __thiscall fn_101792A0(char *self_)
{
  g_pCDx->pDevice->CreateVertexShader(&g_zoneVSDeclA, nullptr, self_ + CTsZoneMap_vsHandleA, 0);
  return g_pCDx->pDevice->CreateVertexShader(&g_zoneVSDeclB, nullptr, self_ + CTsZoneMap_vsHandleB, 0);
}

// PLACED: hand: operates on CTsZoneMap (was in gfx_free_017.cpp)
// FUNCTION: FFXIMAIN 0x1017ADE0
// GATE: PASS -- 100 trials, 35 returned normally, 380 D3D calls compared (diffemu_gfx, clean build)
XI_API int __thiscall fn_1017ADE0(_DWORD *self_, _DWORD *a2)
{
  IDirect3DDevice8 *pDevice;
  int result;
  _BYTE *v6;
  int v7;
  int *v8;
  int v10;
  *(self_ + CTsZoneMap_field_39138 / 4) = -1;
  g_pCDx->pDevice->SetRenderState(D3DRS_NORMALIZENORMALS, FALSE);
  *(self_ + CTsZoneMap_field_39118 / 4) = 0;
  g_pCDx->pDevice->SetRenderState(D3DRS_FOGENABLE, TRUE);
  if ( g_pCDx->supportsTableFog != 0 )
  {
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGVERTEXMODE, D3DFOG_NONE);
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_LINEAR);
    pDevice = g_pCDx->pDevice;
LABEL_3:
    pDevice->SetRenderState(D3DRS_RANGEFOGENABLE, FALSE);
    goto LABEL_4;
  }
  if ( g_pCDx->supportsVertexFog != 0 )
  {
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGVERTEXMODE, D3DFOG_LINEAR);
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_NONE);
    pDevice = g_pCDx->pDevice;
    if ( g_pCDx->supportsRangeFog == 0 )
      goto LABEL_3;
    pDevice->SetRenderState(D3DRS_RANGEFOGENABLE, TRUE);
  }
LABEL_4:
  v10 = 0;
  result = a2[ZoneCellList_cellCount / 4];
  if ( result > 0 )
  {
    v6 = (_BYTE *)(a2[ZoneCellList_cells / 4] + ZoneCell_meshIdCount);
    do
    {
      v7 = 0;
      if ( *v6 != 0 )
      {
        v8 = (int *)(v6 - (ZoneCell_meshIdCount - ZoneCell_meshIds));
        do
        {
          orig::ZoneMap_DrawMeshById((int)self_, a2[ZoneCellList_drawArg / 4], *v8);
          ++v7;
          ++v8;
        }
        while ( v7 < (unsigned __int8)*v6 );
      }
      result = v10 + 1;
      v6 += ZoneCell_size;
      ++v10;
    }
    while ( v10 < a2[ZoneCellList_cellCount / 4] );
  }
  return result;
}

// PLACED: hand: operates on CTsZoneMap (was in gfx_free_018.cpp)
// FUNCTION: FFXIMAIN 0x101844C0
// GATE: PASS -- 100 trials, 12 returned normally, 619 D3D calls compared (diffemu_gfx, clean build)
XI_API void __thiscall fn_101844C0(int *self_, int a2, int a3)
{
  _DWORD *v4;
  float *v5;
  unsigned int v6;
  CDx *v7;
  IDirect3DDevice8 *pDevice;
  IDirect3DDevice8 *v9;
  struct IDirect3DDevice8Vtbl *lpVtbl;
  IDirect3DDevice8 *v11;
  struct IDirect3DDevice8Vtbl *v12;
  int *v13;
  int v14;
  int v15;
  int v16;
  IDirect3DDevice8 *v17;
  int v18;
  IDirect3DBaseTexture8 *v19;
  int v20;
  int v21;
  unsigned int v22;
  int v23;
  unsigned int v24;
  float *v25;
  unsigned int v26;
  unsigned int v27;
  float v28[26];
  float v29[26];
  v4 = *(_DWORD **)(a2 + ZoneDrawDesc_mesh);
  if ( v4 == nullptr )
    return;
  v25 = nullptr;
  if ( C != 0 )
  {
    v5 = (float *)orig::ZoneMap_FindLight(ZoneLightTag_l_01);
    v25 = v5;
    if ( v5 != nullptr )
    {
      g_pCDx->pDevice->LightEnable(*(self_ + CTsZoneMap_lightSlotNamed / 4), 1u);
      orig::CDx_SetLight(g_pCDx, *(self_ + CTsZoneMap_lightSlotNamed / 4), v5 + ZoneLight_light / 4);
    }
    else
    {
      g_pCDx->pDevice->LightEnable(*(self_ + CTsZoneMap_lightSlotNamed / 4), 0);
    }
  }
  g_pCDx->pDevice->SetRenderState(D3DRS_LIGHTING, TRUE);
  memset(v28, 0, sizeof(v28));
  if ( *(self_ + CTsZoneMap_useTwoDirLights / 4) != 0 )
  {
    orig::XiZone_GetDirLights(g_pXiZone, v28, v29);
    orig::CDx_SetLight(g_pCDx, *(self_ + CTsZoneMap_lightSlotDir0 / 4), v28);
    orig::CDx_SetLight(g_pCDx, *(self_ + CTsZoneMap_lightSlotDir1 / 4), v29);
    g_pCDx->pDevice->LightEnable(*(self_ + CTsZoneMap_lightSlotDir0 / 4), 1u);
    v6 = *(self_ + CTsZoneMap_lightSlotDir1 / 4);
  }
  else
  {
    orig::XiZone_GetDirLight((void *)g_pXiZone, v28, 0, 0);
    orig::CDx_SetLight(g_pCDx, *(self_ + CTsZoneMap_lightSlotDir0 / 4), v28);
    v6 = *(self_ + CTsZoneMap_lightSlotDir0 / 4);
  }
  g_pCDx->pDevice->LightEnable(v6, 1u);
  orig::XiZone_GetAmbient((char *)g_pXiZone, &v22, 0, 0);
  orig::XiZone_GetFog((void *)g_pXiZone, &v26, (float *)&v27, (float *)&v24, 0, 0);
  g_pCDx->pDevice->SetRenderState(D3DRS_AMBIENT, v22);
  g_pCDx->pDevice->SetRenderState(D3DRS_FOGENABLE, TRUE);
  v7 = g_pCDx;
  if ( g_pCDx->supportsTableFog != 0 )
  {
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGVERTEXMODE, D3DFOG_NONE);
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_LINEAR);
    pDevice = g_pCDx->pDevice;
    goto LABEL_11;
  }
  if ( g_pCDx->supportsVertexFog != 0 )
  {
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGVERTEXMODE, D3DFOG_LINEAR);
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_NONE);
    pDevice = g_pCDx->pDevice;
    if ( g_pCDx->supportsRangeFog != 0 )
    {
      pDevice->SetRenderState(D3DRS_RANGEFOGENABLE, TRUE);
      goto LABEL_12;
    }
LABEL_11:
    pDevice->SetRenderState(D3DRS_RANGEFOGENABLE, FALSE);
LABEL_12:
    v7 = g_pCDx;
  }
  v7->pDevice->SetRenderState(D3DRS_FOGCOLOR, v26);
  g_pCDx->pDevice->SetRenderState(D3DRS_FOGSTART, v24);
  g_pCDx->pDevice->SetRenderState(D3DRS_FOGEND, v27);
  g_pCDx->pDevice->SetMaterial(self_ + CTsZoneMap_material / 4);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_POINT);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE2X);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_CURRENT);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE4X);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_CURRENT);
  g_pCDx->pDevice->SetTextureStageState(1u, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
  g_pCDx->pDevice->SetTextureStageState(1u, D3DTSS_COLOROP, D3DTOP_DISABLE);
  g_pCDx->pDevice->SetTextureStageState(2u, D3DTSS_COLOROP, D3DTOP_DISABLE);
  g_pCDx->pDevice->SetTextureStageState(2u, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_ADDRESSU, D3DTADDRESS_WRAP);
  g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_ADDRESSV, D3DTADDRESS_WRAP);
  g_pCDx->pDevice->SetTextureStageState(1u, D3DTSS_ADDRESSU, D3DTADDRESS_CLAMP);
  g_pCDx->pDevice->SetTextureStageState(1u, D3DTSS_ADDRESSV, D3DTADDRESS_CLAMP);
  orig::Gfx_SetZBias(g_zbiasZoneMesh);
  g_pCDx->pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
  v9 = g_pCDx->pDevice;
  lpVtbl = v9->lpVtbl;
  if ( a3 != 0 )
  {
    lpVtbl->SetRenderState(v9, D3DRS_ALPHATESTENABLE, 1u);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATER);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHAREF, 96u);
  }
  else
  {
    lpVtbl->SetRenderState(v9, D3DRS_ALPHATESTENABLE, 0);
  }
  g_pCDx->pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
  g_pCDx->pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
  v11 = g_pCDx->pDevice;
  v12 = v11->lpVtbl;
  if ( *(_WORD *)(a2 + ZoneDrawDesc_cullCW) != 0 )
    v12->SetRenderState(v11, D3DRS_CULLMODE, 2u);
  else
    v12->SetRenderState(v11, D3DRS_CULLMODE, 3u);
  *(self_ + CTsZoneMap_curTwoSided / 4) = 0;
  orig::CDx_SetTransform(&g_pCDx->vftable, 256, (const void *)(a2 + ZoneDrawDesc_world));
  v13 = (int *)v4[ZoneMesh_groups / 4];
  if ( v13 != nullptr )
  {
    v14 = v4[ZoneMesh_groupCount / 4];
    v23 = 0;
    if ( v14 > 0 )
    {
      do
      {
        v21 = 0;
        if ( v13[ZoneMeshGroup_batchCount / 4] > 0 )
        {
          v15 = v13[ZoneMeshGroup_batches / 4] + ZoneMeshBatch_tex;
          do
          {
            if ( *(_DWORD *)(v15 + ZoneMeshBatch_vb - ZoneMeshBatch_tex) != 0 )
            {
              orig::CDx_SetLight(g_pCDx, 0, v28);
              g_pCDx->pDevice->SetRenderState(D3DRS_AMBIENT, v22);
              g_pCDx->pDevice->SetRenderState(D3DRS_FOGCOLOR, v26);
              g_pCDx->pDevice->SetRenderState(D3DRS_FOGSTART, v24);
              g_pCDx->pDevice->SetRenderState(D3DRS_FOGEND, v27);
              v16 = *(__int16 *)(v15 + ZoneMeshBatch_twoSided - ZoneMeshBatch_tex);
              if ( v16 != *(self_ + CTsZoneMap_curTwoSided / 4) )
              {
                *(self_ + CTsZoneMap_curTwoSided / 4) = v16;
                if ( v16 != 0 )
                {
                  g_pCDx->pDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
                }
                else
                {
                  v17 = g_pCDx->pDevice;
                  if ( *(self_ + CTsZoneMap_cullCW / 4) != 0 )
                    v17->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
                  else
                    v17->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
                }
              }
              v18 = *(_DWORD *)v15;
              if ( *(_DWORD *)v15 != 0 )
              {
                if ( *(_DWORD *)(v18 + CYyTex_pTexture) != 0 )
                  v19 = *(IDirect3DBaseTexture8 **)(v18 + CYyTex_pTexture);
                else
                  v19 = *(IDirect3DBaseTexture8 **)(v18 + CYyTex_pTextureAlt);
                g_pCDx->pDevice->SetTexture(0, v19);
              }
              else
              {
                g_pCDx->pDevice->SetTexture(0, nullptr);
              }
              g_pCDx->pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, *(__int16 *)(v15 + ZoneMeshBatch_alphaBlend - ZoneMeshBatch_tex));
              g_pCDx->pDevice->SetVertexShader(v4[ZoneMesh_vertexShader / 4]);
              g_pCDx->pDevice->lpVtbl->SetStreamSource(
                g_pCDx->pDevice,
                0,
                *(IDirect3DVertexBuffer8 **)(v15 + ZoneMeshBatch_vb - ZoneMeshBatch_tex),
                v4[ZoneMesh_stride / 4]);
              orig::CDx_DrawPrimitive(g_pCDx, v4[ZoneMesh_primType / 4], 0, *(_DWORD *)(v15 + ZoneMeshBatch_primCount - ZoneMeshBatch_tex));
            }
            v15 += ZoneMeshBatch_size;
            ++v21;
          }
          while ( v21 < v13[ZoneMeshGroup_batchCount / 4] );
        }
        v20 = v4[ZoneMesh_groupCount / 4];
        v13 += ZoneMeshGroup_size / 4;
        ++v23;
      }
      while ( v23 < v20 );
    }
    g_pCDx->pDevice->SetRenderState(D3DRS_AMBIENT, 0);
    g_pCDx->pDevice->SetRenderState(D3DRS_LIGHTING, TRUE);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
    g_pCDx->pDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    if ( v25 != nullptr )
      g_pCDx->pDevice->LightEnable(*(self_ + CTsZoneMap_lightSlotNamed / 4), 0);
  }
}

// PLACED: hand: operates on CTsZoneMap (was in gfx_free_018.cpp)
// FUNCTION: FFXIMAIN 0x10184C90
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API int __thiscall fn_10184C90(void *self_, int a1, int a2, int a3)
{
  int result;
  IDirect3DBaseTexture8 *v6;
  float v7;
  float v8;
  float v9[16];
  float v10[16];
  _BYTE v11[64];
  result = *((_DWORD *)self_ + CTsZoneMap_overlayTex / 4);
  if ( result != 0 )
  {
    v6 = *(IDirect3DBaseTexture8 **)(result + CYyTex_pTexture);
    if ( v6 == nullptr )
      v6 = *(IDirect3DBaseTexture8 **)(result + CYyTex_pTextureAlt);
    g_pCDx->pDevice->SetTexture(0, v6);
    g_pCDx->pDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    g_pCDx->pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ZERO);
    g_pCDx->pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCCOLOR);
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
    g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_POINT);
    g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_POINT);
    g_pCDx->pDevice->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
    g_pCDx->pDevice->SetVertexShader(322u);
    if ( *((_BYTE *)self_ + CTsZoneMap_overlayUseProjection) != 0 )
    {
      g_pCDx->pDevice->GetTransform(D3DTS_PROJECTION, v11);
      orig::ZoneMap_SetOverlayProjection((float *)self_);
    }
    else
    {
      orig::Gfx_SetZBias(g_zbiasOverlay);
    }
    if ( *(float *)&a2 == 0.0 )
    {
      g_overlayScaleZ = 1065353216;
      g_overlayScaleX = 1065353216;
    }
    else
    {
      g_overlayScaleZ = a2;
      g_overlayScaleX = a2;
    }
    v9[0] = 1.0;
    memset(&v9[1], 0, 16);
    v9[5] = 1.0;
    memset(&v9[6], 0, 16);
    v9[10] = 1.0;
    memset(&v9[11], 0, 16);
    v9[15] = 1.0;
    orig::sub_10175740(v10);
    LODWORD(v10[0]) = g_overlayScaleX;
    LODWORD(v10[5]) = g_overlayScaleY;
    LODWORD(v10[10]) = g_overlayScaleZ;
    orig::sub_1016C060(v9, (int)v9, v10);
    orig::sub_10175740(v10);
    v7 = *(float *)(a1 + 4);
    v10[12] = *(float *)a1;
    v8 = *(float *)(a1 + 8);
    v10[13] = v7;
    v10[14] = v8;
    orig::sub_1016C060(v9, (int)v9, v10);
    orig::CDx_SetTransform(&g_pCDx->vftable, 256, v9);
    orig::CDx_DrawPrimitiveUP(g_pCDx, 5, 2, (int)&g_overlayQuadVerts, 24);
    g_pCDx->pDevice->SetRenderState(D3DRS_LIGHTING, TRUE);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
    g_pCDx->pDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
    if ( *((_BYTE *)self_ + CTsZoneMap_overlayUseProjection) != 0 )
      return g_pCDx->pDevice->SetTransform(D3DTS_PROJECTION, v11);
    else
      return orig::Gfx_SetZBias(g_zbiasRestore);
  }
  return result;
}

