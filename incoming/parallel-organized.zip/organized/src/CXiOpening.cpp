// CXiOpening.cpp -- source unit CXiOpening. Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: stores CXiOpening_vtbl into this (ctor/dtor) (was in gfx_free_001.cpp)
// FUNCTION: FFXIMAIN 0x100186C0
// GATE: PASS -- 100 trials, 30 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API void * __thiscall fn_100186C0(void *self_, char *Source)
{
  _DWORD *v3;
  int v4;
  _DWORD *v5;
  _DWORD *v6;
  _DWORD *v7;
  *(_DWORD *)self_ = &CXiOpening_vtbl;
  *((_DWORD *)self_ + 72) = 0;
  *((_DWORD *)self_ + 73) = 0;
  dword_10456D20 = 0;
  *((_DWORD *)self_ + 66) = 0;
  *((_DWORD *)self_ + 68) = 0;
  if ( g_pCDx->supportsFullscreenGamma != 0 )
  {
    orig::sub_100170D0(&g_pCDx->_pad_10[484], (_DWORD *)self_ + 69, (_DWORD *)self_ + 70, (_DWORD *)self_ + 71);
    orig::sub_100170A0(&g_pCDx->_pad_10[484], 1065353216, 1065353216, 1065353216);
  }
  orig::_strncpy((char *)self_ + 4, Source, 0x103u);
  v3 = orig::Allocator_Generic(0x14u);
  if ( v3 != nullptr )
  {
    v4 = *(_DWORD *)(g_pSceneState + 8);
    if ( *(char *)(g_pSceneState + 24) < 0 && (v4 == 2 || v4 == 3) )
      v4 = 1;
    v5 = orig::sub_10018A50(v3, v4);
  }
  else
  {
    v5 = nullptr;
  }
  *((_DWORD *)self_ + 72) = v5;
  if ( v5 != nullptr )
  {
    orig::sub_10018B30(v5);
    v6 = orig::Allocator_Generic(0x3Cu);
    if ( v6 != nullptr )
      v7 = orig::sub_10018C50(v6);
    else
      v7 = nullptr;
    *((_DWORD *)self_ + 73) = v7;
    if ( v7 != nullptr )
      orig::sub_10018CE0(v7);
  }
  return self_;
}

// PLACED: stores CXiOpening_vtbl into this (ctor/dtor) (was in gfx_free_001.cpp)
// FUNCTION: FFXIMAIN 0x100187D0
// GATE: PASS -- 100 trials, 11 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API CDx * __thiscall fn_100187D0(int *self_)
{
  void (__thiscall ***v2)(_DWORD, int);
  void (__thiscall ***v3)(_DWORD, int);
  CDx *result;
  v2 = (void (__thiscall ***)(_DWORD, int))*(self_ + 72);
  *self_ = (int)&CXiOpening_vtbl;
  if ( v2 != nullptr )
  {
    (**v2)(v2, 1);
    *(self_ + 72) = 0;
  }
  v3 = (void (__thiscall ***)(_DWORD, int))*(self_ + 73);
  if ( v3 != nullptr )
  {
    (**v3)(v3, 1);
    *(self_ + 73) = 0;
  }
  result = g_pCDx;
  if ( g_pCDx->supportsFullscreenGamma != 0 )
    return (CDx *)orig::sub_100170A0(&g_pCDx->_pad_10[484], *(self_ + 69), *(self_ + 70), *(self_ + 71));
  return result;
}

