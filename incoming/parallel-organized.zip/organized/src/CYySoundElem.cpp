// CYySoundElem.cpp -- source unit CYySoundElem. Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: between 0x100369f0 (stores CYySoundElem_vtbl into this (ctor/dtor)) and 0x10036af0 (stores CYySoundElem_vtbl into this (ctor/dtor)), both within 4 KB (was in gfx_free_003.cpp)
// FUNCTION: FFXIMAIN 0x10036A80
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API void __stdcall CMoElem_vf013(int a1)
{
  ;
}

// PLACED: between 0x100369f0 (stores CYySoundElem_vtbl into this (ctor/dtor)) and 0x10036af0 (stores CYySoundElem_vtbl into this (ctor/dtor)), both within 4 KB (was in gfx_free_003.cpp)
// FUNCTION: FFXIMAIN 0x10036A90
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API void __stdcall CMoElem_vf014(int a1)
{
  ;
}

// PLACED: between 0x100369f0 (stores CYySoundElem_vtbl into this (ctor/dtor)) and 0x10036af0 (stores CYySoundElem_vtbl into this (ctor/dtor)), both within 4 KB (was in gfx_free_003.cpp)
// FUNCTION: FFXIMAIN 0x10036AA0
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API int __cdecl CMoElem_vf015(void)
{
  return 0;
}

// PLACED: between 0x100369f0 (stores CYySoundElem_vtbl into this (ctor/dtor)) and 0x10036af0 (stores CYySoundElem_vtbl into this (ctor/dtor)), both within 4 KB (was in gfx_free_003.cpp)
// FUNCTION: FFXIMAIN 0x10036AB0
// GATE: PASS -- 100 trials, 100 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API void __cdecl CMoElem_vf019(void)
{
  ;
}

