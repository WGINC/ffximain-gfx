// CXiActorNameDraw.cpp -- source unit CXiActorNameDraw. Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: name CXiActorNameDraw_SetRenderState (was in gfx_free_008.cpp)
// FUNCTION: FFXIMAIN 0x100817F0
// NOT VERIFIED: gate INCONCLUSIVE (both sides faulted on every trial; no returning run to compare)
XI_API int __cdecl CXiActorNameDraw_SetRenderState(void)
{
  int v0;
  int result;
  int i;
  __int16 v3; // fps
  double v4;
  bool v5; // c0
  char v6; // c2
  bool v7; // c3

  result = g_pSceneState;
  if ( *(_DWORD *)g_pSceneState == 96 )
  {
    ((void (__stdcall *)(IDirect3DDevice8 *, int, int, int))g_pCDx->pDevice->lpVtbl->SetRenderState)(
      g_pCDx->pDevice,
      14,
      1,
      v0);
    g_pCDx->pDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATER);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHAREF, 0);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    g_pCDx->pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    g_pCDx->pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
    g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
    g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE2X);
    g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_DIFFUSE);
    g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_TEXTURE);
    g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE4X);
    g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
    g_pCDx->pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_TEXTURE);
    g_pCDx->pDevice->SetTextureStageState(1u, D3DTSS_COLOROP, D3DTOP_DISABLE);
    g_pCDx->pDevice->SetTextureStageState(1u, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
    for ( i = g_pActorDrawListHead; i != 0; i = *(_DWORD *)(i + 84) )
    {
      v4 = *(float *)(i + 140);
      v5 = v4 < 0.0;
      v6 = 0;
      v7 = v4 == 0.0;
      if ( (v3 & 0x100) == 0 )
        (*(void (__thiscall **)(int))(*(_DWORD *)i + 644))(i);
    }
    ((void (__stdcall *)(IDirect3DDevice8 *, int))g_pCDx->pDevice->lpVtbl->SetRenderState)(g_pCDx->pDevice, 14);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_ALWAYS);
    g_pCDx->pDevice->SetRenderState(D3DRS_ALPHAREF, 96u);
    result = g_pCDx->pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
  }
  LOBYTE(result) = 0;
  return result;
}

