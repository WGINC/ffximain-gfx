// sqgxTexture.cpp -- original source: sqgxTexture.c (dancer middleware, C). Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: PS2 name sqgxTexture* (was in gfx_free_028.cpp)
// FUNCTION: FFXIMAIN 0x10281830
// GATE: PASS -- 100 trials, 53 returned normally, 0 D3D calls compared (diffemu_gfx, clean build)
XI_API int __cdecl fn_10281830(int a1, int a2, int a3, _BYTE *a4)
{
  int v4;
  int v5;
  int *v6;
  int v8;
  _BYTE *v9;
  int v10;
  v4 = a3;
  v5 = 0;
  v10 = 0;
  if ( g_counter_109A261C > 0 )
  {
    v6 = dword_1099D61C;
    do
    {
      if ( v6[5] == -1 && *v6 == a1 && v6[1] == a2 && v6[2] == a3 )
        break;
      ++v5;
      v6 += 10;
    }
    while ( v5 < g_counter_109A261C );
  }
  if ( v5 == g_counter_109A261C )
  {
    if ( g_counter_109A261C == 512 )
    {
      orig::sub_10285890(aErrorSqgxtextu);
      return -1;
    }
    v8 = 10 * v5;
    ++g_counter_109A261C;
    dword_1099D61C[v8] = a1;
    dword_1099D620[v8] = a2;
    dword_1099D624[v8] = v4;
    dword_1099D628[10 * v5] = orig::sub_10281810(a1);
    dword_1099D62C[10 * v5] = orig::sub_10281810(a2);
  }
  v9 = a4;
  dword_1099D618[10 * v5] = (int)a4;
  switch ( v4 )
  {
    case 4:
      v10 = 21;
      break;
    case 3:
      v10 = 22;
      break;
    case 2:
      v10 = 51;
      break;
    case 1:
      v10 = *(_DWORD *)(g_pSqgxContext + 720) != 0 ? 50 : 41;
      break;
    default:
      break;
  }
  dword_1099D630[10 * v5] = v10;
  if ( v9 != nullptr )
  {
    orig::Dev_CreateTexture_10281510(v5, v9);
  }
  else
  {
    orig::sub_10285890(aCreatingTextur);
    if ( g_pDancerDevice->lpVtbl->CreateTexture(
           g_pDancerDevice,
           dword_1099D61C[10 * v5],
           dword_1099D620[10 * v5],
           1u,
           1u,
           (D3DFORMAT)dword_1099D630[10 * v5],
           D3DPOOL_DEFAULT,
           (IDirect3DTexture8 **)&a3) != 0 )
      orig::sub_10285890(aError);
    dword_1099D638[10 * v5] = a3;
  }
  dword_1099D634[10 * v5] = -2;
  dword_1099D63C[10 * v5] = 0;
  return v5;
}

// PLACED: between 0x10281830 (PS2 name sqgxTexture*) and 0x10281b60 (PS2 name sqgxTexture*), both within 4 KB (was in gfx_free_028.cpp)
// FUNCTION: FFXIMAIN 0x102819D0
// GATE: PASS -- 100 trials, 8 returned normally, 8 D3D calls compared (diffemu_gfx, clean build)
XI_API int __cdecl fn_102819D0(int a1, int a2, int a3)
{
  signed int i;
  int v4;
  _BYTE *v5;
  _BYTE v7[1024];
  for ( i = 1; i < 256; ++i )
  {
    if ( byte_109A2620[i] == 0 )
      break;
  }
  v4 = 0;
  byte_109A2620[i] = 1;
  v5 = (_BYTE *)(a3 + 2);
  do
  {
    v7[4 * v4] = *(v5 - 2);
    v7[4 * v4 + 1] = *(v5 - 1);
    v7[4 * v4 + 2] = *v5;
    if ( a2 == 3 )
      v7[4 * v4 + 3] = 0;
    else
      v7[4 * v4 + 3] = v5[1];
    ++v4;
    v5 += a2;
  }
  while ( v4 < 256 );
  g_pDancerDevice->SetPaletteEntries(i, v7);
  return i;
}

// PLACED: between 0x10281c80 (PS2 name sqgxTexture*) and 0x10282010 (PS2 name sqgxTexture*), both within 4 KB (was in gfx_free_028.cpp)
// FUNCTION: FFXIMAIN 0x10281D60
// GATE: PASS -- 100 trials, 100 returned normally, 86 D3D calls compared (diffemu_gfx, clean build)
XI_API int __cdecl fn_10281D60(int a1)
{
  int result;
  result = a1;
  if ( a1 >= 0 )
    return g_pDancerDevice->SetCurrentTexturePalette(a1);
  if ( a1 == -1 )
  {
    result = *(_DWORD *)(g_pSqgxContext + 4 * *(_DWORD *)(g_pSqgxContext + 2840) + 2224);
    if ( dword_1099D624[10 * result] == 1 )
      return g_pDancerDevice->SetCurrentTexturePalette(0);
  }
  return result;
}

// PLACED: PS2 name sqgxTexture* (was in gfx_free_028.cpp)
// FUNCTION: FFXIMAIN 0x10282010
// GATE: PASS -- 100 trials, 100 returned normally, 100 D3D calls compared (diffemu_gfx, clean build)
XI_API int __cdecl fn_10282010(int a1)
{
  return ((int (__stdcall *)(IDirect3DDevice8 *, _DWORD, _DWORD, int, _DWORD, _DWORD, int))g_pDancerDevice->lpVtbl->Clear)(
           g_pDancerDevice,
           0,
           0,
           4,
           0,
           0,
           a1);
}

// PLACED: PS2 name sqgxTexture* (was in gfx_free_028.cpp)
// FUNCTION: FFXIMAIN 0x10282190
// GATE: PASS -- 100 trials, 1 returned normally, 1 D3D calls compared (diffemu_gfx, clean build)
XI_API int __cdecl fn_10282190(int a1, char a2)
{
  int v2;
  IDirect3DSurface8 *v3;
  float v5;
  float v6;
  float v7;
  float v8;
  *(_DWORD *)(g_pSqgxContext + sqgxContext_drawBuf) = a1;
  v2 = *(_DWORD *)(g_pSqgxContext + sqgxContext_zBuf);
  if ( v2 == *(_DWORD *)(g_pSqgxContext + sqgxContext_defaultZBuf) )
    v3 = *(IDirect3DSurface8 **)(g_pSqgxContext + 2304);
  else
    v3 = (IDirect3DSurface8 *)dword_1099D63C[10 * v2];
  if ( a2 != 0 )
  {
    v7 = (double)*(int *)(g_pSqgxContext + sqgxContext_displayY) / (double)dword_1099D620[10 * a1];
    v5 = (double)*(int *)(g_pSqgxContext + sqgxContext_displayX) / (double)dword_1099D61C[10 * a1];
    orig::sub_102838A0(v5, v7);
  }
  else
  {
    orig::sub_102838A0(1.0, 1.0);
  }
  if ( a1 == *(_DWORD *)(g_pSqgxContext + sqgxContext_defaultDrawBuf) )
  {
    g_pDancerDevice->SetRenderTarget(*(IDirect3DSurface8 **)(g_pSqgxContext + 2300), v3);
  }
  else
  {
    if ( dword_1099D63C[10 * a1] == 0 )
      (*(void (__stdcall **)(int, _DWORD, int *))(*(_DWORD *)dword_1099D638[10 * a1] + 60))(
        dword_1099D638[10 * a1],
        0,
        &dword_1099D63C[10 * a1]);
    g_pDancerDevice->SetRenderTarget((IDirect3DSurface8 *)dword_1099D63C[10 * a1], v3);
  }
  v8 = (float)dword_1099D620[10 * a1];
  v6 = (float)dword_1099D61C[10 * a1];
  return orig::Dev_SetViewport_10283A10(0.0, 0.0, v6, v8);
}

