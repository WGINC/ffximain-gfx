// sqgxBlend.cpp -- original source: sqgxBlend.c (dancer middleware, C). Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: PS2 name sqgxBlend* (was in gfx_free_028.cpp)
// FUNCTION: FFXIMAIN 0x10283220
// GATE: PASS -- 100 trials, 100 returned normally, 100 D3D calls compared (diffemu_gfx, clean build)
XI_API int __cdecl fn_10283220(void)
{
  return g_pDancerDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}

