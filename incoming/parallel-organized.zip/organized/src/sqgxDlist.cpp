// sqgxDlist.cpp -- original source: sqgxDlist.c (dancer middleware, C). Functions placed here by source-layout evidence (see each one).
#include "gfx_all.hpp"

// ---- free functions (no class proven) whose source-layout evidence puts them in this unit ----
// PLACED: between 0x1029b620 (asserts sqgxDlist.c) and 0x1029bb60 (asserts sqgxDlist.c), both within 4 KB (was in gfx_free_029.cpp)
// FUNCTION: FFXIMAIN 0x1029B9D0
// GATE: PASS -- 100 trials, 2 returned normally, 8 D3D calls compared (diffemu_gfx, clean build)
XI_API void __cdecl fn_1029B9D0(IDirect3DVertexBuffer8 **a1)
{
  unsigned int v1;
  int v2;
  int v4;
  IDirect3DIndexBuffer8 *v5;
  IDirect3DIndexBuffer8 *v6;
  unsigned int v7;
  unsigned int v8;
  unsigned int v9;
  int v10;
  v1 = 0;
  orig::sub_1028A730(0, 0);
  orig::sqgxShape_1028AFE0();
  v2 = g_pSqgxContext;
  if ( (*(_BYTE *)(g_pSqgxContext + sqgxContext_vtx) & 1) != 0 )
  {
    v1 = 1;
    g_pDancerDevice->SetStreamSource(0, *a1, 12u);
    v2 = g_pSqgxContext;
  }
  if ( (*(_BYTE *)(v2 + 2608) & 2) != 0 )
  {
    v8 = v1++;
    g_pDancerDevice->SetStreamSource(v8, a1[1], 12u);
    v2 = g_pSqgxContext;
  }
  v10 = 0;
  if ( *(_DWORD *)(v2 + 2840) + 1 > 0 )
  {
    v4 = 653;
    do
    {
      if ( (*(_BYTE *)(v4 * 4 + v2) & 4) != 0 )
      {
        v7 = v1++;
        g_pDancerDevice->SetStreamSource(v7, a1[v4 - 651], 8u);
        v2 = g_pSqgxContext;
      }
      ++v4;
      ++v10;
    }
    while ( v10 < *(_DWORD *)(v2 + 2840) + 1 );
  }
  if ( (*(_BYTE *)(v2 + 2608) & 8) != 0 )
  {
    v9 = v1++;
    g_pDancerDevice->SetStreamSource(v9, a1[4], 4u);
    v2 = g_pSqgxContext;
  }
  if ( (*(_BYTE *)(v2 + 2608) & 0x10) != 0 )
    g_pDancerDevice->SetStreamSource(v1, a1[5], 12u);
  v5 = (IDirect3DIndexBuffer8 *)a1[7];
  if ( v5 != nullptr )
  {
    g_pDancerDevice->SetIndices(v5, 0);
    g_pDancerDevice->lpVtbl->DrawIndexedPrimitive(
      g_pDancerDevice,
      D3DPT_TRIANGLESTRIP,
      0,
      (unsigned int)a1[6],
      0,
      (unsigned int)a1[8]);
  }
  v6 = (IDirect3DIndexBuffer8 *)a1[9];
  if ( v6 != nullptr )
  {
    g_pDancerDevice->SetIndices(v6, 0);
    g_pDancerDevice->lpVtbl->DrawIndexedPrimitive(
      g_pDancerDevice,
      D3DPT_TRIANGLELIST,
      0,
      (unsigned int)a1[6],
      0,
      (unsigned int)a1[10]);
  }
  orig::sub_1028BBD0();
}

