// gfx_globals.hpp -- game globals the graphics code uses, bound to their addresses.
#pragma once
#include "gfx_common.hpp"
typedef int (*CDx_vtbl_t)();
#define CDx_vtbl XI_EA(CDx_vtbl_t, 0x103299D4u)
typedef int (*CYyObject_vtbl_ambiguous0_t)();
#define CYyObject_vtbl_ambiguous0 XI_EA(CYyObject_vtbl_ambiguous0_t, 0x103299F0u)
typedef char * CShader_classdesc_t;
#define CShader_classdesc XI_EA(CShader_classdesc_t, 0x10329EC4u)
typedef int (*CXiOpening_vtbl_t)();
#define CXiOpening_vtbl XI_EA(CXiOpening_vtbl_t, 0x10329FBCu)
typedef char * CYyModelDt_classdesc_t;
#define CYyModelDt_classdesc XI_EA(CYyModelDt_classdesc_t, 0x1032A6B8u)
typedef char * CYyModelBase_classdesc_t;
#define CYyModelBase_classdesc XI_EA(CYyModelBase_classdesc_t, 0x1032A6C4u)
typedef char * CYyModel_classdesc_t;
#define CYyModel_classdesc XI_EA(CYyModel_classdesc_t, 0x1032A6D0u)
typedef int (*CYyOs2VtxBuffer_vtbl_t)();
#define CYyOs2VtxBuffer_vtbl XI_EA(CYyOs2VtxBuffer_vtbl_t, 0x1032A7B0u)
typedef char * CYyTexBase_classdesc_t;
#define CYyTexBase_classdesc XI_EA(CYyTexBase_classdesc_t, 0x1032AA34u)
typedef char * CYyTexMng_classdesc_t;
#define CYyTexMng_classdesc XI_EA(CYyTexMng_classdesc_t, 0x1032AA84u)
typedef char * CMoAttachments_classdesc_t;
#define CMoAttachments_classdesc XI_EA(CMoAttachments_classdesc_t, 0x1032AAFCu)
typedef char * CMoCamera_classdesc_t;
#define CMoCamera_classdesc XI_EA(CMoCamera_classdesc_t, 0x1032AB28u)
typedef char * CMoCameraTask_classdesc_t;
#define CMoCameraTask_classdesc XI_EA(CMoCameraTask_classdesc_t, 0x1032AB34u)
typedef char * CMoCelestial_classdesc_t;
#define CMoCelestial_classdesc XI_EA(CMoCelestial_classdesc_t, 0x1032AB9Cu)
typedef char * CMoD3aElem_classdesc_t;
#define CMoD3aElem_classdesc XI_EA(CMoD3aElem_classdesc_t, 0x1032ABECu)
typedef char * CMoD3aLightmapElem_classdesc_t;
#define CMoD3aLightmapElem_classdesc XI_EA(CMoD3aLightmapElem_classdesc_t, 0x1032ABF8u)
typedef char * CMoVuAnmElem_classdesc_t;
#define CMoVuAnmElem_classdesc XI_EA(CMoVuAnmElem_classdesc_t, 0x1032AC04u)
typedef char * CMoD3mSpecularElem_classdesc_t;
#define CMoD3mSpecularElem_classdesc XI_EA(CMoD3mSpecularElem_classdesc_t, 0x1032AD08u)
typedef int (*CMoD3mSpecularElem_vtbl_t)();
#define CMoD3mSpecularElem_vtbl XI_EA(CMoD3mSpecularElem_vtbl_t, 0x1032AD20u)
typedef int (*CMoOtTask_vtbl_ambiguous1_t)();
#define CMoOtTask_vtbl_ambiguous1 XI_EA(CMoOtTask_vtbl_ambiguous1_t, 0x1032AEB0u)
typedef char * CMoDisintegrateProgElem_classdesc_t;
#define CMoDisintegrateProgElem_classdesc XI_EA(CMoDisintegrateProgElem_classdesc_t, 0x1032AEE0u)
typedef char * CMoDist_classdesc_t;
#define CMoDist_classdesc XI_EA(CMoDist_classdesc_t, 0x1032AEECu)
typedef char * CMoVuDist_classdesc_t;
#define CMoVuDist_classdesc XI_EA(CMoVuDist_classdesc_t, 0x1032AEF8u)
typedef char * CMoDistModelElem_classdesc_t;
#define CMoDistModelElem_classdesc XI_EA(CMoDistModelElem_classdesc_t, 0x1032AF20u)
typedef char * CMoDistMorphElem_classdesc_t;
#define CMoDistMorphElem_classdesc XI_EA(CMoDistMorphElem_classdesc_t, 0x1032AF2Cu)
typedef char * CMoDistRingElem_classdesc_t;
#define CMoDistRingElem_classdesc XI_EA(CMoDistRingElem_classdesc_t, 0x1032AF38u)
typedef char * CMoElem_classdesc_t;
#define CMoElem_classdesc XI_EA(CMoElem_classdesc_t, 0x1032AFF0u)
typedef char * CMoNullProgElem_classdesc_t;
#define CMoNullProgElem_classdesc XI_EA(CMoNullProgElem_classdesc_t, 0x1032AFFCu)
typedef char * CMoSkeletonElem_classdesc_t;
#define CMoSkeletonElem_classdesc XI_EA(CMoSkeletonElem_classdesc_t, 0x1032B008u)
typedef int (*CMoElem_vtbl_ambiguous3_t)();
#define CMoElem_vtbl_ambiguous3 XI_EA(CMoElem_vtbl_ambiguous3_t, 0x1032B018u)
typedef char * CMoGeneratorClone_classdesc_t;
#define CMoGeneratorClone_classdesc XI_EA(CMoGeneratorClone_classdesc_t, 0x1032B108u)
typedef int (*mixin_of_CMoGeneratorClone_0x1032B680_t)();
#define mixin_of_CMoGeneratorClone_0x1032B680 XI_EA(mixin_of_CMoGeneratorClone_0x1032B680_t, 0x1032B680u)
typedef int (*CMoGeneratorClone_vtbl_t)();
#define CMoGeneratorClone_vtbl XI_EA(CMoGeneratorClone_vtbl_t, 0x1032B69Cu)
typedef char * CMoLfdElem_classdesc_t;
#define CMoLfdElem_classdesc XI_EA(CMoLfdElem_classdesc_t, 0x1032B6C8u)
typedef char * CMoOT_classdesc_t;
#define CMoOT_classdesc XI_EA(CMoOT_classdesc_t, 0x1032B6DCu)
typedef char * CMoOtTask_classdesc_t;
#define CMoOtTask_classdesc XI_EA(CMoOtTask_classdesc_t, 0x1032B6E8u)
typedef char * CMoPathObject_classdesc_t;
#define CMoPathObject_classdesc XI_EA(CMoPathObject_classdesc_t, 0x1032B710u)
typedef char * CMoRabRes_classdesc_t;
#define CMoRabRes_classdesc XI_EA(CMoRabRes_classdesc_t, 0x1032B71Cu)
typedef char * CMoSphRes_classdesc_t;
#define CMoSphRes_classdesc XI_EA(CMoSphRes_classdesc_t, 0x1032B728u)
typedef char * CMoPointLightProgElem_classdesc_t;
#define CMoPointLightProgElem_classdesc XI_EA(CMoPointLightProgElem_classdesc_t, 0x1032B74Cu)
typedef char * CMoPathDriveActorTask_classdesc_t;
#define CMoPathDriveActorTask_classdesc XI_EA(CMoPathDriveActorTask_classdesc_t, 0x1032B7BCu)
typedef char * CMoLockColorDriveTask_classdesc_t;
#define CMoLockColorDriveTask_classdesc XI_EA(CMoLockColorDriveTask_classdesc_t, 0x1032B7C8u)
typedef char * CMoLockLookAtDriveTask_classdesc_t;
#define CMoLockLookAtDriveTask_classdesc XI_EA(CMoLockLookAtDriveTask_classdesc_t, 0x1032B7D4u)
typedef char * CMoActorColorDriveTask_classdesc_t;
#define CMoActorColorDriveTask_classdesc XI_EA(CMoActorColorDriveTask_classdesc_t, 0x1032B7E0u)
typedef char * CMoActorRotationDriveTask_classdesc_t;
#define CMoActorRotationDriveTask_classdesc XI_EA(CMoActorRotationDriveTask_classdesc_t, 0x1032B7ECu)
typedef char * CMoSchedularTask_classdesc_t;
#define CMoSchedularTask_classdesc XI_EA(CMoSchedularTask_classdesc_t, 0x1032B7F8u)
typedef char * CMoSpline_classdesc_t;
#define CMoSpline_classdesc XI_EA(CMoSpline_classdesc_t, 0x1032C074u)
typedef char * CMoVuLineProgElem_classdesc_t;
#define CMoVuLineProgElem_classdesc XI_EA(CMoVuLineProgElem_classdesc_t, 0x1032C0C0u)
typedef char * CMoDX_classdesc_t;
#define CMoDX_classdesc XI_EA(CMoDX_classdesc_t, 0x1032C0CCu)
typedef char * CMoDxStatusMng_classdesc_t;
#define CMoDxStatusMng_classdesc XI_EA(CMoDxStatusMng_classdesc_t, 0x1032C100u)
typedef char * CMoOcclusionMng_classdesc_t;
#define CMoOcclusionMng_classdesc XI_EA(CMoOcclusionMng_classdesc_t, 0x1032C16Cu)
typedef char * CMoProcessor_classdesc_t;
#define CMoProcessor_classdesc XI_EA(CMoProcessor_classdesc_t, 0x1032C1BCu)
typedef char * CMoResource_classdesc_t;
#define CMoResource_classdesc XI_EA(CMoResource_classdesc_t, 0x1032C46Cu)
typedef char * CMoResourceMng_classdesc_t;
#define CMoResourceMng_classdesc XI_EA(CMoResourceMng_classdesc_t, 0x1032C47Cu)
typedef char * CMoTask_classdesc_t;
#define CMoTask_classdesc XI_EA(CMoTask_classdesc_t, 0x1032C960u)
typedef char * CMoTaskMng_classdesc_t;
#define CMoTaskMng_classdesc XI_EA(CMoTaskMng_classdesc_t, 0x1032C96Cu)
typedef char * CXiSkeletonActor_classdesc_t;
#define CXiSkeletonActor_classdesc XI_EA(CXiSkeletonActor_classdesc_t, 0x10330EBCu)
typedef char * CXiSkeletonActorRes_classdesc_t;
#define CXiSkeletonActorRes_classdesc XI_EA(CXiSkeletonActorRes_classdesc_t, 0x10330EC8u)
typedef int (*CXiSkeletonActorRes_vtbl_t)();
#define CXiSkeletonActorRes_vtbl XI_EA(CXiSkeletonActorRes_vtbl_t, 0x103313ACu)
typedef int dword_10333000_t[];
#define dword_10333000 XI_EA(dword_10333000_t, 0x10333000u)
typedef int dword_10333004_t[];
#define dword_10333004 XI_EA(dword_10333004_t, 0x10333004u)
typedef int dword_10333008_t[];
#define dword_10333008 XI_EA(dword_10333008_t, 0x10333008u)
typedef int (*CTsZoneMap_vtbl_t)();
#define CTsZoneMap_vtbl XI_EA(CTsZoneMap_vtbl_t, 0x10336748u)
typedef char aDeviceLost_t[1];
#define aDeviceLost XI_EA(aDeviceLost_t, 0x1034F6A0u)
typedef char aMenuChdummy_t[1];
#define aMenuChdummy XI_EA(aMenuChdummy_t, 0x103502E8u)
typedef char ClassName_t[1];
#define ClassName XI_EA(ClassName_t, 0x10350350u)
typedef char aFinalFantasyXi_t[1];
#define aFinalFantasyXi XI_EA(aFinalFantasyXi_t, 0x10350450u)
typedef _BYTE unk_1035055C_t;
#define unk_1035055C XI_EA(unk_1035055C_t, 0x1035055Cu)
typedef _BYTE unk_1035055E_t;
#define unk_1035055E XI_EA(unk_1035055E_t, 0x1035055Eu)
typedef char aAfbVersionErro_t[1];
#define aAfbVersionErro XI_EA(aAfbVersionErro_t, 0x103511B0u)
typedef _BYTE unk_10351628_t;
#define g_vsDecl_1628 XI_EA(unk_10351628_t, 0x10351628u)
typedef void * off_103601BC_t;
#define off_103601BC XI_EA(off_103601BC_t, 0x103601BCu)
typedef char aCellTextureTex_1_t[1];
#define aCellTextureTex_1 XI_EA(aCellTextureTex_1_t, 0x1036C238u)
typedef char aCellTextureTex_0_t[1];
#define aCellTextureTex_0 XI_EA(aCellTextureTex_0_t, 0x1036C25Cu)
typedef char aCellTextureTex_t[1];
#define aCellTextureTex XI_EA(aCellTextureTex_t, 0x1036C27Cu)
typedef char aCellTextureFra_t[1];
#define aCellTextureFra XI_EA(aCellTextureFra_t, 0x1036C29Cu)
typedef char aCellTextureZer_t[1];
#define aCellTextureZer XI_EA(aCellTextureZer_t, 0x1036C2B8u)
typedef char aCellFrameTextu_t[1];
#define aCellFrameTextu XI_EA(aCellFrameTextu_t, 0x1036C2D8u)
typedef char aCellFrameFrame_1_t[1];
#define aCellFrameFrame_1 XI_EA(aCellFrameFrame_1_t, 0x1036C2F4u)
typedef char aCellFrameFrame_0_t[1];
#define aCellFrameFrame_0 XI_EA(aCellFrameFrame_0_t, 0x1036C314u)
typedef char aCellFrameFrame_t[1];
#define aCellFrameFrame XI_EA(aCellFrameFrame_t, 0x1036C330u)
typedef char aCellZeroTextur_0_t[1];
#define aCellZeroTextur_0 XI_EA(aCellZeroTextur_0_t, 0x1036C34Cu)
typedef char aCellZeroTextur_t[1];
#define aCellZeroTextur XI_EA(aCellZeroTextur_t, 0x1036C36Cu)
typedef char aCellZeroFrameZ_t[1];
#define aCellZeroFrameZ XI_EA(aCellZeroFrameZ_t, 0x1036C388u)
typedef char aCellZeroZeroTe_t[1];
#define aCellZeroZeroTe XI_EA(aCellZeroZeroTe_t, 0x1036C3A4u)
typedef char aCellZeroZeroFr_t[1];
#define aCellZeroZeroFr XI_EA(aCellZeroZeroFr_t, 0x1036C3C0u)
typedef char aCellZeroZeroZe_t[1];
#define aCellZeroZeroZe XI_EA(aCellZeroZeroZe_t, 0x1036C3DCu)
typedef int dword_1036E4EC_t[];
#define dword_1036E4EC XI_EA(dword_1036E4EC_t, 0x1036E4ECu)
typedef char aAncAncScro_t[1];
#define aAncAncScro XI_EA(aAncAncScro_t, 0x1036E6C8u)
typedef char aMenuKeytops3_t[1];
#define aMenuKeytops3 XI_EA(aMenuKeytops3_t, 0x1036FFC8u)
typedef _BYTE unk_103772E8_t;
#define g_zoneVSDeclA XI_EA(unk_103772E8_t, 0x103772E8u)
typedef _BYTE unk_10377304_t;
#define g_zoneVSDeclB XI_EA(unk_10377304_t, 0x10377304u)
typedef int dword_10377350_t;
#define g_overlayScaleX XI_EA(dword_10377350_t, 0x10377350u)
typedef int dword_10377354_t;
#define g_overlayScaleY XI_EA(dword_10377354_t, 0x10377354u)
typedef int dword_10377358_t;
#define g_overlayScaleZ XI_EA(dword_10377358_t, 0x10377358u)
typedef _BYTE unk_10377360_t;
#define g_overlayQuadVerts XI_EA(unk_10377360_t, 0x10377360u)
typedef float flt_10389874_t[7];
#define kF_0_9874 XI_EA(flt_10389874_t, 0x10389874u)
typedef char aWorkmem_t[1];
#define aWorkmem XI_EA(aWorkmem_t, 0x1038992Cu)
typedef char aMainmem_t[1];
#define aMainmem XI_EA(aMainmem_t, 0x10389934u)
typedef char aMainpool0x08xB_t[1];
#define aMainpool0x08xB XI_EA(aMainpool0x08xB_t, 0x1038993Cu)
typedef char aWorkpool0x08xB_t[1];
#define aWorkpool0x08xB XI_EA(aWorkpool0x08xB_t, 0x1038995Cu)
typedef char aMemtotal0x08xB_t[1];
#define aMemtotal0x08xB XI_EA(aMemtotal0x08xB_t, 0x10389984u)
typedef char aErrorCouldnTAl_t[1];
#define aErrorCouldnTAl XI_EA(aErrorCouldnTAl_t, 0x103899A4u)
typedef char aErrorSqgxtextu_t[1];
#define aErrorSqgxtextu XI_EA(aErrorSqgxtextu_t, 0x103B48A8u)
typedef char aError_t[1];
#define aError XI_EA(aError_t, 0x103B48D0u)
typedef char aCreatingTextur_t[1];
#define aCreatingTextur XI_EA(aCreatingTextur_t, 0x103B48D8u)
typedef int dword_103B4910_t[1024];
#define dword_103B4910 XI_EA(dword_103B4910_t, 0x103B4910u)
typedef int dword_103B5910_t[];
#define dword_103B5910 XI_EA(dword_103B5910_t, 0x103B5910u)
typedef int dword_103B5914_t[2047];
#define dword_103B5914 XI_EA(dword_103B5914_t, 0x103B5914u)
typedef int dword_103BA68C_t;
#define g_sceneFadeMaskRT XI_EA(dword_103BA68C_t, 0x103BA68Cu)
typedef int dword_103D3C64_t;
#define dword_103D3C64 XI_EA(dword_103D3C64_t, 0x103D3C64u)
typedef int dword_103D3CB8_t;
#define dword_103D3CB8 XI_EA(dword_103D3CB8_t, 0x103D3CB8u)
typedef D3DHolder * g_pD3DHolder_t;
#define g_pD3DHolder XI_EA(g_pD3DHolder_t, 0x103D3CBCu)
typedef CDx * g_pCDx_t;
#define g_pCDx XI_EA(g_pCDx_t, 0x1045666Cu)
typedef int g_pEnv_t;
#define g_pEnv XI_EA(g_pEnv_t, 0x104566E8u)
typedef __int16 word_104568F8_t;
#define word_104568F8 XI_EA(word_104568F8_t, 0x104568F8u)
typedef int dword_1045694C_t;
#define dword_1045694C XI_EA(dword_1045694C_t, 0x1045694Cu)
typedef int dword_10456978_t;
#define g_countdown_10456978 XI_EA(dword_10456978_t, 0x10456978u)
typedef int dword_10456984_t;
#define dword_10456984 XI_EA(dword_10456984_t, 0x10456984u)
typedef HWND hWnd_t;
#define hWnd XI_EA(hWnd_t, 0x104569A8u)
typedef HINSTANCE hmod_t;
#define hmod XI_EA(hmod_t, 0x104569ACu)
typedef int dword_104569B0_t;
#define dword_104569B0 XI_EA(dword_104569B0_t, 0x104569B0u)
typedef int dword_104569B4_t;
#define dword_104569B4 XI_EA(dword_104569B4_t, 0x104569B4u)
typedef int dword_104569B8_t;
#define dword_104569B8 XI_EA(dword_104569B8_t, 0x104569B8u)
typedef int dword_104569BC_t;
#define dword_104569BC XI_EA(dword_104569BC_t, 0x104569BCu)
typedef int dword_104569C0_t;
#define dword_104569C0 XI_EA(dword_104569C0_t, 0x104569C0u)
typedef int dword_104569D0_t;
#define dword_104569D0 XI_EA(dword_104569D0_t, 0x104569D0u)
typedef HKEY phkResult_t;
#define phkResult XI_EA(phkResult_t, 0x104569D4u)
typedef char byte_104569EC_t;
#define byte_104569EC XI_EA(byte_104569EC_t, 0x104569ECu)
typedef int dword_104569F4_t;
#define dword_104569F4 XI_EA(dword_104569F4_t, 0x104569F4u)
typedef _BYTE unk_10456A00_t;
#define unk_10456A00 XI_EA(unk_10456A00_t, 0x10456A00u)
typedef int g_pSceneState_t;
#define g_pSceneState XI_EA(g_pSceneState_t, 0x10456A28u)
typedef int dword_10456A2C_t;
#define dword_10456A2C XI_EA(dword_10456A2C_t, 0x10456A2Cu)
typedef int xRight_t;
#define xRight XI_EA(xRight_t, 0x10456A58u)
typedef int g_timeOfDayTintEnabled_t;
#define g_timeOfDayTintEnabled XI_EA(g_timeOfDayTintEnabled_t, 0x10456A7Cu)
typedef int dword_10456A80_t;
#define dword_10456A80 XI_EA(dword_10456A80_t, 0x10456A80u)
typedef int dword_10456A88_t;
#define dword_10456A88 XI_EA(dword_10456A88_t, 0x10456A88u)
typedef int dword_10456AA0_t;
#define dword_10456AA0 XI_EA(dword_10456AA0_t, 0x10456AA0u)
typedef int dword_10456BF8_t;
#define dword_10456BF8 XI_EA(dword_10456BF8_t, 0x10456BF8u)
typedef int yBottom_t;
#define yBottom XI_EA(yBottom_t, 0x10456C08u)
typedef int dword_10456D20_t;
#define dword_10456D20 XI_EA(dword_10456D20_t, 0x10456D20u)
typedef char byte_10456D48_t;
#define byte_10456D48 XI_EA(byte_10456D48_t, 0x10456D48u)
typedef int dword_10456D4C_t;
#define dword_10456D4C XI_EA(dword_10456D4C_t, 0x10456D4Cu)
typedef int dword_10456D50_t;
#define dword_10456D50 XI_EA(dword_10456D50_t, 0x10456D50u)
typedef int dword_10456D54_t;
#define dword_10456D54 XI_EA(dword_10456D54_t, 0x10456D54u)
typedef int dword_10456D58_t;
#define dword_10456D58 XI_EA(dword_10456D58_t, 0x10456D58u)
typedef int dword_10456D5C_t;
#define dword_10456D5C XI_EA(dword_10456D5C_t, 0x10456D5Cu)
typedef int g_alignedBufferSize_t;
#define g_alignedBufferSize XI_EA(g_alignedBufferSize_t, 0x10456E40u)
typedef int dword_10456E4C_t;
#define g_vertexShader_6E4C XI_EA(dword_10456E4C_t, 0x10456E4Cu)
typedef int dword_10456E6C_t;
#define dword_10456E6C XI_EA(dword_10456E6C_t, 0x10456E6Cu)
typedef int dword_10456E70_t;
#define dword_10456E70 XI_EA(dword_10456E70_t, 0x10456E70u)
typedef int dword_10457148_t;
#define g_vertexBuffer_7148 XI_EA(dword_10457148_t, 0x10457148u)
typedef int dword_1045714C_t;
#define g_vertexBuffer_714C XI_EA(dword_1045714C_t, 0x1045714Cu)
typedef int dword_10457150_t;
#define g_vertexBuffer_7150 XI_EA(dword_10457150_t, 0x10457150u)
typedef int dword_10457154_t;
#define g_vertexBuffer_7154 XI_EA(dword_10457154_t, 0x10457154u)
typedef _BYTE unk_10457228_t;
#define g_matrix_7228 XI_EA(unk_10457228_t, 0x10457228u)
typedef _DWORD dword_10457270_t[16];
#define g_matrix_7270 XI_EA(dword_10457270_t, 0x10457270u)
typedef _DWORD dword_10457468_t[16];
#define g_matrix_7468 XI_EA(dword_10457468_t, 0x10457468u)
typedef _DWORD dword_104574B8_t[16];
#define dword_104574B8 XI_EA(dword_104574B8_t, 0x104574B8u)
typedef int dword_10457540_t;
#define g_vertexBuffer_7540 XI_EA(dword_10457540_t, 0x10457540u)
typedef int dword_10457548_t;
#define dword_10457548 XI_EA(dword_10457548_t, 0x10457548u)
typedef int dword_10457554_t[5];
#define dword_10457554 XI_EA(dword_10457554_t, 0x10457554u)
typedef int dword_1045B650_t[16];
#define dword_1045B650 XI_EA(dword_1045B650_t, 0x1045B650u)
typedef int dword_1045B690_t[];
#define dword_1045B690 XI_EA(dword_1045B690_t, 0x1045B690u)
typedef int dword_1045B6A0_t;
#define g_vertexShader_B6A0 XI_EA(dword_1045B6A0_t, 0x1045B6A0u)
typedef __int16 word_1045B77A_t;
#define word_1045B77A XI_EA(word_1045B77A_t, 0x1045B77Au)
typedef int dword_1045B800_t;
#define dword_1045B800 XI_EA(dword_1045B800_t, 0x1045B800u)
typedef int dword_1045B804_t;
#define dword_1045B804 XI_EA(dword_1045B804_t, 0x1045B804u)
typedef int dword_1045B808_t;
#define g_texturefactor_B808 XI_EA(dword_1045B808_t, 0x1045B808u)
typedef float flt_1045B80C_t;
#define flt_1045B80C XI_EA(flt_1045B80C_t, 0x1045B80Cu)
typedef int g_boneWeightMatrixTable_t;
#define g_boneWeightMatrixTable XI_EA(g_boneWeightMatrixTable_t, 0x1045EC20u)
typedef int g_pSharedSkeleton_t[];
#define g_pSharedSkeleton XI_EA(g_pSharedSkeleton_t, 0x1045EC24u)
typedef int dword_1045EC28_t[256];
#define dword_1045EC28 XI_EA(dword_1045EC28_t, 0x1045EC28u)
typedef float g_poseScratch_t[];
#define g_poseScratch XI_EA(g_poseScratch_t, 0x1045F030u)
typedef _DWORD dword_1045F040_t[3];
#define dword_1045F040 XI_EA(dword_1045F040_t, 0x1045F040u)
typedef _DWORD dword_1045F04C_t[3];
#define dword_1045F04C XI_EA(dword_1045F04C_t, 0x1045F04Cu)
typedef _BYTE unk_1045F064_t;
#define unk_1045F064 XI_EA(unk_1045F064_t, 0x1045F064u)
typedef int dword_1047B974_t;
#define dword_1047B974 XI_EA(dword_1047B974_t, 0x1047B974u)
typedef int g_pVertexBufferListHead_t;
#define g_pVertexBufferListHead XI_EA(g_pVertexBufferListHead_t, 0x1047B978u)
typedef int dword_1047BBB0_t;
#define dword_1047BBB0 XI_EA(dword_1047BBB0_t, 0x1047BBB0u)
typedef int g_scratchValue_t;
#define g_scratchValue XI_EA(g_scratchValue_t, 0x1047BC0Cu)
typedef int dword_1047BC6C_t;
#define g_countdown_1047BC6C XI_EA(dword_1047BC6C_t, 0x1047BC6Cu)
typedef int g_pResourceMng_t;
#define g_pResourceMng XI_EA(g_pResourceMng_t, 0x1047BFA8u)
typedef int dword_1047CC80_t;
#define g_identityMatrix_1047CC80_m00 XI_EA(dword_1047CC80_t, 0x1047CC80u)
typedef int dword_1047CC84_t;
#define g_identityMatrix_1047CC80_m01 XI_EA(dword_1047CC84_t, 0x1047CC84u)
typedef int dword_1047CC88_t;
#define g_identityMatrix_1047CC80_m02 XI_EA(dword_1047CC88_t, 0x1047CC88u)
typedef int dword_1047CC8C_t;
#define g_identityMatrix_1047CC80_m03 XI_EA(dword_1047CC8C_t, 0x1047CC8Cu)
typedef int dword_1047CC90_t;
#define g_identityMatrix_1047CC80_m10 XI_EA(dword_1047CC90_t, 0x1047CC90u)
typedef int dword_1047CC94_t;
#define g_identityMatrix_1047CC80_m11 XI_EA(dword_1047CC94_t, 0x1047CC94u)
typedef int dword_1047CC98_t;
#define g_identityMatrix_1047CC80_m12 XI_EA(dword_1047CC98_t, 0x1047CC98u)
typedef int dword_1047CC9C_t;
#define g_identityMatrix_1047CC80_m13 XI_EA(dword_1047CC9C_t, 0x1047CC9Cu)
typedef int dword_1047CCA0_t;
#define g_identityMatrix_1047CC80_m20 XI_EA(dword_1047CCA0_t, 0x1047CCA0u)
typedef int dword_1047CCA4_t;
#define g_identityMatrix_1047CC80_m21 XI_EA(dword_1047CCA4_t, 0x1047CCA4u)
typedef int dword_1047CCA8_t;
#define g_identityMatrix_1047CC80_m22 XI_EA(dword_1047CCA8_t, 0x1047CCA8u)
typedef int dword_1047CCAC_t;
#define g_identityMatrix_1047CC80_m23 XI_EA(dword_1047CCAC_t, 0x1047CCACu)
typedef int dword_1047CCB0_t;
#define g_identityMatrix_1047CC80_m30 XI_EA(dword_1047CCB0_t, 0x1047CCB0u)
typedef int dword_1047CCB4_t;
#define g_identityMatrix_1047CC80_m31 XI_EA(dword_1047CCB4_t, 0x1047CCB4u)
typedef int dword_1047CCB8_t;
#define g_identityMatrix_1047CC80_m32 XI_EA(dword_1047CCB8_t, 0x1047CCB8u)
typedef int dword_1047CCBC_t;
#define g_identityMatrix_1047CC80_m33 XI_EA(dword_1047CCBC_t, 0x1047CCBCu)
typedef char byte_1047CF31_t;
#define byte_1047CF31 XI_EA(byte_1047CF31_t, 0x1047CF31u)
typedef CMoProcessor * g_pProcessor_t;
#define g_pProcessor XI_EA(g_pProcessor_t, 0x1047CF7Cu)
typedef int g_pMeshResourceMng_t;
#define g_pMeshResourceMng XI_EA(g_pMeshResourceMng_t, 0x1047D128u)
typedef char byte_1047D12C_t;
#define byte_1047D12C XI_EA(byte_1047D12C_t, 0x1047D12Cu)
typedef int dword_1047D150_t;
#define dword_1047D150 XI_EA(dword_1047D150_t, 0x1047D150u)
typedef int dword_1047D158_t;
#define dword_1047D158 XI_EA(dword_1047D158_t, 0x1047D158u)
typedef int dword_1047D200_t;
#define dword_1047D200 XI_EA(dword_1047D200_t, 0x1047D200u)
typedef int g_pActorDrawListHead_t;
#define g_pActorDrawListHead XI_EA(g_pActorDrawListHead_t, 0x1047D578u)
typedef char byte_1047D580_t;
#define byte_1047D580 XI_EA(byte_1047D580_t, 0x1047D580u)
typedef int g_pActiveSkeletonActorRes_t;
#define g_pActiveSkeletonActorRes XI_EA(g_pActiveSkeletonActorRes_t, 0x1048A3D8u)
typedef _BYTE unk_104E1B70_t;
#define g_viewport_1B70 XI_EA(unk_104E1B70_t, 0x104E1B70u)
typedef int dword_104E1BF8_t[17];
#define dword_104E1BF8 XI_EA(dword_104E1BF8_t, 0x104E1BF8u)
typedef __int16 word_10621838_t[14];
#define word_10621838 XI_EA(word_10621838_t, 0x10621838u)
typedef int dword_106218B4_t;
#define dword_106218B4 XI_EA(dword_106218B4_t, 0x106218B4u)
typedef int dword_106218B8_t;
#define dword_106218B8 XI_EA(dword_106218B8_t, 0x106218B8u)
typedef _BYTE unk_10621904_t;
#define g_viewport_1904 XI_EA(unk_10621904_t, 0x10621904u)
typedef int dword_10621988_t;
#define g_upVerts_1988 XI_EA(dword_10621988_t, 0x10621988u)
typedef float flt_1062198C_t;
#define g_upVerts_1988_v0_y XI_EA(flt_1062198C_t, 0x1062198Cu)
typedef float flt_10621990_t;
#define g_upVerts_1988_v0_z XI_EA(flt_10621990_t, 0x10621990u)
typedef int dword_10621998_t;
#define g_upVerts_1988_v1_x XI_EA(dword_10621998_t, 0x10621998u)
typedef float flt_1062199C_t;
#define g_upVerts_1988_v1_y XI_EA(flt_1062199C_t, 0x1062199Cu)
typedef float flt_106219A0_t;
#define g_upVerts_1988_v1_z XI_EA(flt_106219A0_t, 0x106219A0u)
typedef int dword_106219A8_t;
#define g_upVerts_1988_v2_x XI_EA(dword_106219A8_t, 0x106219A8u)
typedef float flt_106219AC_t;
#define g_upVerts_1988_v2_y XI_EA(flt_106219AC_t, 0x106219ACu)
typedef float flt_106219B0_t;
#define g_upVerts_1988_v2_z XI_EA(flt_106219B0_t, 0x106219B0u)
typedef int dword_106219B8_t;
#define g_upVerts_1988_v3_x XI_EA(dword_106219B8_t, 0x106219B8u)
typedef float flt_106219BC_t;
#define g_upVerts_1988_v3_y XI_EA(flt_106219BC_t, 0x106219BCu)
typedef float flt_106219C0_t;
#define g_upVerts_1988_v3_z XI_EA(flt_106219C0_t, 0x106219C0u)
typedef int dword_106219C8_t;
#define g_upVerts_1988_v4_x XI_EA(dword_106219C8_t, 0x106219C8u)
typedef float flt_106219CC_t;
#define g_upVerts_1988_v4_y XI_EA(flt_106219CC_t, 0x106219CCu)
typedef float flt_106219D0_t;
#define g_upVerts_1988_v4_z XI_EA(flt_106219D0_t, 0x106219D0u)
typedef int dword_106219D8_t;
#define g_upVerts_1988_v5_x XI_EA(dword_106219D8_t, 0x106219D8u)
typedef float flt_106219DC_t;
#define g_upVerts_1988_v5_y XI_EA(flt_106219DC_t, 0x106219DCu)
typedef float flt_106219E0_t;
#define g_upVerts_1988_v5_z XI_EA(flt_106219E0_t, 0x106219E0u)
typedef int dword_10621A08_t;
#define dword_10621A08 XI_EA(dword_10621A08_t, 0x10621A08u)
typedef int dword_10621A10_t;
#define dword_10621A10 XI_EA(dword_10621A10_t, 0x10621A10u)
typedef int dword_10621A18_t;
#define g_upVerts_1A18 XI_EA(dword_10621A18_t, 0x10621A18u)
typedef int dword_10621A1C_t;
#define g_upVerts_1A18_v0_y XI_EA(dword_10621A1C_t, 0x10621A1Cu)
typedef int dword_10621A20_t;
#define g_upVerts_1A18_v0_z XI_EA(dword_10621A20_t, 0x10621A20u)
typedef int dword_10621A24_t;
#define g_upVerts_1A18_v0_diffuse XI_EA(dword_10621A24_t, 0x10621A24u)
typedef int dword_10621A28_t;
#define g_upVerts_1A18_v1_x XI_EA(dword_10621A28_t, 0x10621A28u)
typedef int dword_10621A2C_t;
#define g_upVerts_1A18_v1_y XI_EA(dword_10621A2C_t, 0x10621A2Cu)
typedef int dword_10621A30_t;
#define g_upVerts_1A18_v1_z XI_EA(dword_10621A30_t, 0x10621A30u)
typedef int dword_10621A34_t;
#define g_upVerts_1A18_v1_diffuse XI_EA(dword_10621A34_t, 0x10621A34u)
typedef int dword_10621A38_t;
#define g_upVerts_1A18_v2_x XI_EA(dword_10621A38_t, 0x10621A38u)
typedef int dword_10621A3C_t;
#define g_upVerts_1A18_v2_y XI_EA(dword_10621A3C_t, 0x10621A3Cu)
typedef int dword_10621A40_t;
#define g_upVerts_1A18_v2_z XI_EA(dword_10621A40_t, 0x10621A40u)
typedef int dword_10621A44_t;
#define g_upVerts_1A18_v2_diffuse XI_EA(dword_10621A44_t, 0x10621A44u)
typedef int dword_10621A48_t;
#define g_upVerts_1A18_v3_x XI_EA(dword_10621A48_t, 0x10621A48u)
typedef int dword_10621A4C_t;
#define g_upVerts_1A18_v3_y XI_EA(dword_10621A4C_t, 0x10621A4Cu)
typedef int dword_10621A50_t;
#define g_upVerts_1A18_v3_z XI_EA(dword_10621A50_t, 0x10621A50u)
typedef int dword_10621A54_t;
#define g_upVerts_1A18_v3_diffuse XI_EA(dword_10621A54_t, 0x10621A54u)
typedef int dword_10621A58_t;
#define g_upVerts_1A18_v4_x XI_EA(dword_10621A58_t, 0x10621A58u)
typedef int dword_10621A5C_t;
#define g_upVerts_1A18_v4_y XI_EA(dword_10621A5C_t, 0x10621A5Cu)
typedef int dword_10621A60_t;
#define g_upVerts_1A18_v4_z XI_EA(dword_10621A60_t, 0x10621A60u)
typedef int dword_10621A64_t;
#define g_upVerts_1A18_v4_diffuse XI_EA(dword_10621A64_t, 0x10621A64u)
typedef int dword_10621A68_t;
#define g_upVerts_1A68 XI_EA(dword_10621A68_t, 0x10621A68u)
typedef int dword_10621A6C_t;
#define g_upVerts_1A68_v0_y XI_EA(dword_10621A6C_t, 0x10621A6Cu)
typedef int dword_10621A70_t;
#define g_upVerts_1A68_v0_z XI_EA(dword_10621A70_t, 0x10621A70u)
typedef int dword_10621A74_t;
#define g_upVerts_1A68_v0_diffuse XI_EA(dword_10621A74_t, 0x10621A74u)
typedef int dword_10621A78_t;
#define g_upVerts_1A68_v1_x XI_EA(dword_10621A78_t, 0x10621A78u)
typedef int dword_10621A7C_t;
#define g_upVerts_1A68_v1_y XI_EA(dword_10621A7C_t, 0x10621A7Cu)
typedef int dword_10621A80_t;
#define g_upVerts_1A68_v1_z XI_EA(dword_10621A80_t, 0x10621A80u)
typedef int dword_10621A84_t;
#define g_upVerts_1A68_v1_diffuse XI_EA(dword_10621A84_t, 0x10621A84u)
typedef int dword_10621A88_t;
#define g_upVerts_1A68_v2_x XI_EA(dword_10621A88_t, 0x10621A88u)
typedef int dword_10621A8C_t;
#define g_upVerts_1A68_v2_y XI_EA(dword_10621A8C_t, 0x10621A8Cu)
typedef int dword_10621A90_t;
#define g_upVerts_1A68_v2_z XI_EA(dword_10621A90_t, 0x10621A90u)
typedef int dword_10621A94_t;
#define g_upVerts_1A68_v2_diffuse XI_EA(dword_10621A94_t, 0x10621A94u)
typedef int dword_10621A98_t;
#define g_upVerts_1A68_v3_x XI_EA(dword_10621A98_t, 0x10621A98u)
typedef int dword_10621A9C_t;
#define g_upVerts_1A68_v3_y XI_EA(dword_10621A9C_t, 0x10621A9Cu)
typedef int dword_10621AA0_t;
#define g_upVerts_1A68_v3_z XI_EA(dword_10621AA0_t, 0x10621AA0u)
typedef int dword_10621AA4_t;
#define g_upVerts_1A68_v3_diffuse XI_EA(dword_10621AA4_t, 0x10621AA4u)
typedef int dword_10621AA8_t;
#define g_upVerts_1A68_v4_x XI_EA(dword_10621AA8_t, 0x10621AA8u)
typedef int dword_10621AAC_t;
#define g_upVerts_1A68_v4_y XI_EA(dword_10621AAC_t, 0x10621AACu)
typedef int dword_10621AB0_t;
#define g_upVerts_1A68_v4_z XI_EA(dword_10621AB0_t, 0x10621AB0u)
typedef int dword_10621AB4_t;
#define g_upVerts_1A68_v4_diffuse XI_EA(dword_10621AB4_t, 0x10621AB4u)
typedef int dword_10621AB8_t;
#define g_upVerts_1AB8 XI_EA(dword_10621AB8_t, 0x10621AB8u)
typedef int dword_10621ABC_t;
#define g_upVerts_1AB8_v0_y XI_EA(dword_10621ABC_t, 0x10621ABCu)
typedef int dword_10621AC0_t;
#define g_upVerts_1AB8_v0_z XI_EA(dword_10621AC0_t, 0x10621AC0u)
typedef int dword_10621AC4_t;
#define g_upVerts_1AB8_v0_diffuse XI_EA(dword_10621AC4_t, 0x10621AC4u)
typedef int dword_10621AC8_t;
#define g_upVerts_1AB8_v1_x XI_EA(dword_10621AC8_t, 0x10621AC8u)
typedef int dword_10621ACC_t;
#define g_upVerts_1AB8_v1_y XI_EA(dword_10621ACC_t, 0x10621ACCu)
typedef int dword_10621AD0_t;
#define g_upVerts_1AB8_v1_z XI_EA(dword_10621AD0_t, 0x10621AD0u)
typedef int dword_10621AD4_t;
#define g_upVerts_1AB8_v1_diffuse XI_EA(dword_10621AD4_t, 0x10621AD4u)
typedef int dword_10621AD8_t;
#define g_upVerts_1AB8_v2_x XI_EA(dword_10621AD8_t, 0x10621AD8u)
typedef int dword_10621ADC_t;
#define g_upVerts_1AB8_v2_y XI_EA(dword_10621ADC_t, 0x10621ADCu)
typedef int dword_10621AE0_t;
#define g_upVerts_1AB8_v2_z XI_EA(dword_10621AE0_t, 0x10621AE0u)
typedef int dword_10621AE4_t;
#define g_upVerts_1AB8_v2_diffuse XI_EA(dword_10621AE4_t, 0x10621AE4u)
typedef int dword_10621AE8_t;
#define g_upVerts_1AB8_v3_x XI_EA(dword_10621AE8_t, 0x10621AE8u)
typedef int dword_10621AEC_t;
#define g_upVerts_1AB8_v3_y XI_EA(dword_10621AEC_t, 0x10621AECu)
typedef int dword_10621AF0_t;
#define g_upVerts_1AB8_v3_z XI_EA(dword_10621AF0_t, 0x10621AF0u)
typedef int dword_10621AF4_t;
#define g_upVerts_1AB8_v3_diffuse XI_EA(dword_10621AF4_t, 0x10621AF4u)
typedef int dword_10621AF8_t;
#define g_upVerts_1AB8_v4_x XI_EA(dword_10621AF8_t, 0x10621AF8u)
typedef int dword_10621AFC_t;
#define g_upVerts_1AB8_v4_y XI_EA(dword_10621AFC_t, 0x10621AFCu)
typedef int dword_10621B00_t;
#define g_upVerts_1AB8_v4_z XI_EA(dword_10621B00_t, 0x10621B00u)
typedef int dword_10621B04_t;
#define g_upVerts_1AB8_v4_diffuse XI_EA(dword_10621B04_t, 0x10621B04u)
typedef int dword_10621B08_t;
#define g_upVerts_1AB8_v5_x XI_EA(dword_10621B08_t, 0x10621B08u)
typedef int dword_10621B0C_t;
#define g_upVerts_1AB8_v5_y XI_EA(dword_10621B0C_t, 0x10621B0Cu)
typedef int dword_10621B10_t;
#define g_upVerts_1AB8_v5_z XI_EA(dword_10621B10_t, 0x10621B10u)
typedef int dword_10621B14_t;
#define g_upVerts_1AB8_v5_diffuse XI_EA(dword_10621B14_t, 0x10621B14u)
typedef int dword_10621B18_t;
#define g_upVerts_1AB8_v6_x XI_EA(dword_10621B18_t, 0x10621B18u)
typedef int dword_10621B1C_t;
#define g_upVerts_1AB8_v6_y XI_EA(dword_10621B1C_t, 0x10621B1Cu)
typedef int dword_10621B20_t;
#define g_upVerts_1AB8_v6_z XI_EA(dword_10621B20_t, 0x10621B20u)
typedef int dword_10621B24_t;
#define g_upVerts_1AB8_v6_diffuse XI_EA(dword_10621B24_t, 0x10621B24u)
typedef int dword_10621B28_t;
#define g_upVerts_1AB8_v7_x XI_EA(dword_10621B28_t, 0x10621B28u)
typedef int dword_10621B2C_t;
#define g_upVerts_1AB8_v7_y XI_EA(dword_10621B2C_t, 0x10621B2Cu)
typedef int dword_10621B30_t;
#define g_upVerts_1AB8_v7_z XI_EA(dword_10621B30_t, 0x10621B30u)
typedef int dword_10621B34_t;
#define g_upVerts_1AB8_v7_diffuse XI_EA(dword_10621B34_t, 0x10621B34u)
typedef int dword_10621C00_t;
#define g_zbiasRestore XI_EA(dword_10621C00_t, 0x10621C00u)
typedef _BYTE unk_10624DD3_t;
#define unk_10624DD3 XI_EA(unk_10624DD3_t, 0x10624DD3u)
typedef int dword_10631C88_t;
#define g_zbiasOverlay XI_EA(dword_10631C88_t, 0x10631C88u)
typedef int dword_10631C90_t;
#define g_upVerts_1C90 XI_EA(dword_10631C90_t, 0x10631C90u)
typedef float flt_10631C94_t;
#define g_upVerts_1C90_v0_y XI_EA(flt_10631C94_t, 0x10631C94u)
typedef float flt_10631C98_t;
#define g_upVerts_1C90_v0_z XI_EA(flt_10631C98_t, 0x10631C98u)
typedef int dword_10631C9C_t;
#define g_upVerts_1C90_v0_diffuse XI_EA(dword_10631C9C_t, 0x10631C9Cu)
typedef int dword_10631CA0_t;
#define g_upVerts_1C90_v0_u XI_EA(dword_10631CA0_t, 0x10631CA0u)
typedef int dword_10631CA4_t;
#define g_upVerts_1C90_v0_v XI_EA(dword_10631CA4_t, 0x10631CA4u)
typedef int dword_10631CA8_t;
#define g_upVerts_1C90_v1_x XI_EA(dword_10631CA8_t, 0x10631CA8u)
typedef float flt_10631CAC_t;
#define g_upVerts_1C90_v1_y XI_EA(flt_10631CAC_t, 0x10631CACu)
typedef float flt_10631CB0_t;
#define g_upVerts_1C90_v1_z XI_EA(flt_10631CB0_t, 0x10631CB0u)
typedef int dword_10631CB4_t;
#define g_upVerts_1C90_v1_diffuse XI_EA(dword_10631CB4_t, 0x10631CB4u)
typedef int dword_10631CB8_t;
#define g_upVerts_1C90_v1_u XI_EA(dword_10631CB8_t, 0x10631CB8u)
typedef int dword_10631CBC_t;
#define g_upVerts_1C90_v1_v XI_EA(dword_10631CBC_t, 0x10631CBCu)
typedef float flt_10631CC0_t;
#define g_upVerts_1C90_v2_x XI_EA(flt_10631CC0_t, 0x10631CC0u)
typedef float flt_10631CC4_t;
#define g_upVerts_1C90_v2_y XI_EA(flt_10631CC4_t, 0x10631CC4u)
typedef float flt_10631CC8_t;
#define g_upVerts_1C90_v2_z XI_EA(flt_10631CC8_t, 0x10631CC8u)
typedef int dword_10631CCC_t;
#define g_upVerts_1C90_v2_diffuse XI_EA(dword_10631CCC_t, 0x10631CCCu)
typedef int dword_10631CD0_t;
#define g_upVerts_1C90_v2_u XI_EA(dword_10631CD0_t, 0x10631CD0u)
typedef int dword_10631CD4_t;
#define g_upVerts_1C90_v2_v XI_EA(dword_10631CD4_t, 0x10631CD4u)
typedef float flt_10631CD8_t;
#define g_upVerts_1C90_v3_x XI_EA(flt_10631CD8_t, 0x10631CD8u)
typedef float flt_10631CDC_t;
#define g_upVerts_1C90_v3_y XI_EA(flt_10631CDC_t, 0x10631CDCu)
typedef float flt_10631CE0_t;
#define g_upVerts_1C90_v3_z XI_EA(flt_10631CE0_t, 0x10631CE0u)
typedef int dword_10631CE4_t;
#define g_upVerts_1C90_v3_diffuse XI_EA(dword_10631CE4_t, 0x10631CE4u)
typedef int dword_10631CE8_t;
#define g_upVerts_1C90_v3_u XI_EA(dword_10631CE8_t, 0x10631CE8u)
typedef int dword_10631CEC_t;
#define g_upVerts_1C90_v3_v XI_EA(dword_10631CEC_t, 0x10631CECu)
typedef float flt_10631CF0_t;
#define g_upVerts_1C90_v4_x XI_EA(flt_10631CF0_t, 0x10631CF0u)
typedef float flt_10631CF4_t;
#define g_upVerts_1C90_v4_y XI_EA(flt_10631CF4_t, 0x10631CF4u)
typedef float flt_10631CF8_t;
#define g_upVerts_1C90_v4_z XI_EA(flt_10631CF8_t, 0x10631CF8u)
typedef int dword_10631CFC_t;
#define g_upVerts_1C90_v4_diffuse XI_EA(dword_10631CFC_t, 0x10631CFCu)
typedef int dword_10631D00_t;
#define g_upVerts_1C90_v4_u XI_EA(dword_10631D00_t, 0x10631D00u)
typedef int dword_10631D04_t;
#define g_upVerts_1C90_v4_v XI_EA(dword_10631D04_t, 0x10631D04u)
typedef float flt_10631D08_t;
#define g_upVerts_1C90_v5_x XI_EA(flt_10631D08_t, 0x10631D08u)
typedef float flt_10631D0C_t;
#define g_upVerts_1C90_v5_y XI_EA(flt_10631D0C_t, 0x10631D0Cu)
typedef float flt_10631D10_t;
#define g_upVerts_1C90_v5_z XI_EA(flt_10631D10_t, 0x10631D10u)
typedef int dword_10631D14_t;
#define g_upVerts_1C90_v5_diffuse XI_EA(dword_10631D14_t, 0x10631D14u)
typedef int dword_10631D18_t;
#define g_upVerts_1C90_v5_u XI_EA(dword_10631D18_t, 0x10631D18u)
typedef int dword_10631D1C_t;
#define g_upVerts_1C90_v5_v XI_EA(dword_10631D1C_t, 0x10631D1Cu)
typedef int dword_10631D20_t;
#define g_upVerts_1C90_v6_x XI_EA(dword_10631D20_t, 0x10631D20u)
typedef float flt_10631D24_t;
#define g_upVerts_1C90_v6_y XI_EA(flt_10631D24_t, 0x10631D24u)
typedef float flt_10631D28_t;
#define g_upVerts_1C90_v6_z XI_EA(flt_10631D28_t, 0x10631D28u)
typedef int dword_10631D2C_t;
#define g_upVerts_1C90_v6_diffuse XI_EA(dword_10631D2C_t, 0x10631D2Cu)
typedef int dword_10631D30_t;
#define g_upVerts_1C90_v6_u XI_EA(dword_10631D30_t, 0x10631D30u)
typedef int dword_10631D34_t;
#define g_upVerts_1C90_v6_v XI_EA(dword_10631D34_t, 0x10631D34u)
typedef int dword_10631D38_t;
#define g_upVerts_1C90_v7_x XI_EA(dword_10631D38_t, 0x10631D38u)
typedef float flt_10631D3C_t;
#define g_upVerts_1C90_v7_y XI_EA(flt_10631D3C_t, 0x10631D3Cu)
typedef float flt_10631D40_t;
#define g_upVerts_1C90_v7_z XI_EA(flt_10631D40_t, 0x10631D40u)
typedef int dword_10631D44_t;
#define g_upVerts_1C90_v7_diffuse XI_EA(dword_10631D44_t, 0x10631D44u)
typedef int dword_10631D48_t;
#define g_upVerts_1C90_v7_u XI_EA(dword_10631D48_t, 0x10631D48u)
typedef int dword_10631D4C_t;
#define g_upVerts_1C90_v7_v XI_EA(dword_10631D4C_t, 0x10631D4Cu)
typedef int dword_10631D50_t;
#define g_upVerts_1D50 XI_EA(dword_10631D50_t, 0x10631D50u)
typedef float flt_10631D54_t;
#define g_upVerts_1D50_v0_y XI_EA(flt_10631D54_t, 0x10631D54u)
typedef float flt_10631D58_t;
#define g_upVerts_1D50_v0_z XI_EA(flt_10631D58_t, 0x10631D58u)
typedef int dword_10631D5C_t;
#define g_upVerts_1D50_v0_diffuse XI_EA(dword_10631D5C_t, 0x10631D5Cu)
typedef int dword_10631D60_t;
#define g_upVerts_1D50_v0_u XI_EA(dword_10631D60_t, 0x10631D60u)
typedef int dword_10631D64_t;
#define g_upVerts_1D50_v0_v XI_EA(dword_10631D64_t, 0x10631D64u)
typedef float flt_10631D68_t;
#define g_upVerts_1D50_v1_x XI_EA(flt_10631D68_t, 0x10631D68u)
typedef float flt_10631D6C_t;
#define g_upVerts_1D50_v1_y XI_EA(flt_10631D6C_t, 0x10631D6Cu)
typedef float flt_10631D70_t;
#define g_upVerts_1D50_v1_z XI_EA(flt_10631D70_t, 0x10631D70u)
typedef int dword_10631D74_t;
#define g_upVerts_1D50_v1_diffuse XI_EA(dword_10631D74_t, 0x10631D74u)
typedef int dword_10631D78_t;
#define g_upVerts_1D50_v1_u XI_EA(dword_10631D78_t, 0x10631D78u)
typedef int dword_10631D7C_t;
#define g_upVerts_1D50_v1_v XI_EA(dword_10631D7C_t, 0x10631D7Cu)
typedef float flt_10631D80_t;
#define g_upVerts_1D50_v2_x XI_EA(flt_10631D80_t, 0x10631D80u)
typedef float flt_10631D84_t;
#define g_upVerts_1D50_v2_y XI_EA(flt_10631D84_t, 0x10631D84u)
typedef float flt_10631D88_t;
#define g_upVerts_1D50_v2_z XI_EA(flt_10631D88_t, 0x10631D88u)
typedef int dword_10631D8C_t;
#define g_upVerts_1D50_v2_diffuse XI_EA(dword_10631D8C_t, 0x10631D8Cu)
typedef int dword_10631D90_t;
#define g_upVerts_1D50_v2_u XI_EA(dword_10631D90_t, 0x10631D90u)
typedef int dword_10631D94_t;
#define g_upVerts_1D50_v2_v XI_EA(dword_10631D94_t, 0x10631D94u)
typedef int dword_10631D98_t;
#define g_upVerts_1D50_v3_x XI_EA(dword_10631D98_t, 0x10631D98u)
typedef float flt_10631D9C_t;
#define g_upVerts_1D50_v3_y XI_EA(flt_10631D9C_t, 0x10631D9Cu)
typedef float flt_10631DA0_t;
#define g_upVerts_1D50_v3_z XI_EA(flt_10631DA0_t, 0x10631DA0u)
typedef int dword_10631DA4_t;
#define g_upVerts_1D50_v3_diffuse XI_EA(dword_10631DA4_t, 0x10631DA4u)
typedef int dword_10631DA8_t;
#define g_upVerts_1D50_v3_u XI_EA(dword_10631DA8_t, 0x10631DA8u)
typedef int dword_10631DAC_t;
#define g_upVerts_1D50_v3_v XI_EA(dword_10631DAC_t, 0x10631DACu)
typedef int dword_10631DB0_t;
#define g_upVerts_1D50_v4_x XI_EA(dword_10631DB0_t, 0x10631DB0u)
typedef float flt_10631DB4_t;
#define g_upVerts_1D50_v4_y XI_EA(flt_10631DB4_t, 0x10631DB4u)
typedef float flt_10631DB8_t;
#define g_upVerts_1D50_v4_z XI_EA(flt_10631DB8_t, 0x10631DB8u)
typedef int dword_10631DBC_t;
#define g_upVerts_1D50_v4_diffuse XI_EA(dword_10631DBC_t, 0x10631DBCu)
typedef int dword_10631DC0_t;
#define g_upVerts_1D50_v4_u XI_EA(dword_10631DC0_t, 0x10631DC0u)
typedef int dword_10631DC4_t;
#define g_upVerts_1D50_v4_v XI_EA(dword_10631DC4_t, 0x10631DC4u)
typedef int dword_10631E10_t;
#define g_upVerts_1E10 XI_EA(dword_10631E10_t, 0x10631E10u)
typedef float flt_10631E14_t;
#define g_upVerts_1E10_v0_y XI_EA(flt_10631E14_t, 0x10631E14u)
typedef float flt_10631E18_t;
#define g_upVerts_1E10_v0_z XI_EA(flt_10631E18_t, 0x10631E18u)
typedef int dword_10631E1C_t;
#define g_upVerts_1E10_v0_diffuse XI_EA(dword_10631E1C_t, 0x10631E1Cu)
typedef int dword_10631E20_t;
#define g_upVerts_1E10_v0_u XI_EA(dword_10631E20_t, 0x10631E20u)
typedef int dword_10631E24_t;
#define g_upVerts_1E10_v0_v XI_EA(dword_10631E24_t, 0x10631E24u)
typedef float flt_10631E28_t;
#define g_upVerts_1E10_v1_x XI_EA(flt_10631E28_t, 0x10631E28u)
typedef float flt_10631E2C_t;
#define g_upVerts_1E10_v1_y XI_EA(flt_10631E2C_t, 0x10631E2Cu)
typedef float flt_10631E30_t;
#define g_upVerts_1E10_v1_z XI_EA(flt_10631E30_t, 0x10631E30u)
typedef int dword_10631E34_t;
#define g_upVerts_1E10_v1_diffuse XI_EA(dword_10631E34_t, 0x10631E34u)
typedef int dword_10631E38_t;
#define g_upVerts_1E10_v1_u XI_EA(dword_10631E38_t, 0x10631E38u)
typedef int dword_10631E3C_t;
#define g_upVerts_1E10_v1_v XI_EA(dword_10631E3C_t, 0x10631E3Cu)
typedef float flt_10631E40_t;
#define g_upVerts_1E10_v2_x XI_EA(flt_10631E40_t, 0x10631E40u)
typedef float flt_10631E44_t;
#define g_upVerts_1E10_v2_y XI_EA(flt_10631E44_t, 0x10631E44u)
typedef float flt_10631E48_t;
#define g_upVerts_1E10_v2_z XI_EA(flt_10631E48_t, 0x10631E48u)
typedef int dword_10631E4C_t;
#define g_upVerts_1E10_v2_diffuse XI_EA(dword_10631E4C_t, 0x10631E4Cu)
typedef int dword_10631E50_t;
#define g_upVerts_1E10_v2_u XI_EA(dword_10631E50_t, 0x10631E50u)
typedef int dword_10631E54_t;
#define g_upVerts_1E10_v2_v XI_EA(dword_10631E54_t, 0x10631E54u)
typedef int dword_10631E58_t;
#define g_upVerts_1E10_v3_x XI_EA(dword_10631E58_t, 0x10631E58u)
typedef float flt_10631E5C_t;
#define g_upVerts_1E10_v3_y XI_EA(flt_10631E5C_t, 0x10631E5Cu)
typedef float flt_10631E60_t;
#define g_upVerts_1E10_v3_z XI_EA(flt_10631E60_t, 0x10631E60u)
typedef int dword_10631E64_t;
#define g_upVerts_1E10_v3_diffuse XI_EA(dword_10631E64_t, 0x10631E64u)
typedef int dword_10631E68_t;
#define g_upVerts_1E10_v3_u XI_EA(dword_10631E68_t, 0x10631E68u)
typedef int dword_10631E6C_t;
#define g_upVerts_1E10_v3_v XI_EA(dword_10631E6C_t, 0x10631E6Cu)
typedef int dword_10631E70_t;
#define g_upVerts_1E10_v4_x XI_EA(dword_10631E70_t, 0x10631E70u)
typedef float flt_10631E74_t;
#define g_upVerts_1E10_v4_y XI_EA(flt_10631E74_t, 0x10631E74u)
typedef float flt_10631E78_t;
#define g_upVerts_1E10_v4_z XI_EA(flt_10631E78_t, 0x10631E78u)
typedef int dword_10631E7C_t;
#define g_upVerts_1E10_v4_diffuse XI_EA(dword_10631E7C_t, 0x10631E7Cu)
typedef int dword_10631E80_t;
#define g_upVerts_1E10_v4_u XI_EA(dword_10631E80_t, 0x10631E80u)
typedef int dword_10631E84_t;
#define g_upVerts_1E10_v4_v XI_EA(dword_10631E84_t, 0x10631E84u)
typedef int dword_10631F10_t;
#define g_boxIB XI_EA(dword_10631F10_t, 0x10631F10u)
typedef int dword_10631F18_t;
#define g_zbiasPresetAux XI_EA(dword_10631F18_t, 0x10631F18u)
typedef int dword_10631F20_t;
#define g_boxPositionVB XI_EA(dword_10631F20_t, 0x10631F20u)
typedef int dword_10631F24_t;
#define g_pZoneMap XI_EA(dword_10631F24_t, 0x10631F24u)
typedef int dword_10632038_t;
#define g_zbiasZoneMesh XI_EA(dword_10632038_t, 0x10632038u)
typedef int dword_10639040_t;
#define g_boxStream1VB XI_EA(dword_10639040_t, 0x10639040u)
typedef int dword_1065C4D0_t;
#define g_zbiasPreset_C4D0 XI_EA(dword_1065C4D0_t, 0x1065C4D0u)
typedef int g_pCurrentCamera_t;
#define g_pXiZone XI_EA(g_pCurrentCamera_t, 0x1065CB04u)
typedef int dword_10662DCC_t;
#define dword_10662DCC XI_EA(dword_10662DCC_t, 0x10662DCCu)
typedef int C_t;
#define C XI_EA(C_t, 0x106631D4u)
typedef int dword_10668FD8_t;
#define dword_10668FD8 XI_EA(dword_10668FD8_t, 0x10668FD8u)
typedef int dword_10669014_t;
#define dword_10669014 XI_EA(dword_10669014_t, 0x10669014u)
typedef int dword_1066914C_t;
#define g_stateBlock_914C XI_EA(dword_1066914C_t, 0x1066914Cu)
typedef int dword_10669150_t;
#define g_stateBlock_9150 XI_EA(dword_10669150_t, 0x10669150u)
typedef int dword_10669400_t;
#define dword_10669400 XI_EA(dword_10669400_t, 0x10669400u)
typedef int dword_10669404_t;
#define dword_10669404 XI_EA(dword_10669404_t, 0x10669404u)
typedef int dword_10669408_t;
#define dword_10669408 XI_EA(dword_10669408_t, 0x10669408u)
typedef int dword_1066940C_t;
#define dword_1066940C XI_EA(dword_1066940C_t, 0x1066940Cu)
typedef int dword_10669410_t;
#define dword_10669410 XI_EA(dword_10669410_t, 0x10669410u)
typedef IDirect3D8 * dword_10669418_t;
#define dword_10669418 XI_EA(dword_10669418_t, 0x10669418u)
typedef IDirect3DDevice8 * g_pDancerDevice_t;
#define g_pDancerDevice XI_EA(g_pDancerDevice_t, 0x1066941Cu)
typedef int dword_1099D200_t;
#define g_pSqgxContext XI_EA(dword_1099D200_t, 0x1099D200u)
typedef int dword_1099D618_t[];
#define dword_1099D618 XI_EA(dword_1099D618_t, 0x1099D618u)
typedef int dword_1099D61C_t[];
#define dword_1099D61C XI_EA(dword_1099D61C_t, 0x1099D61Cu)
typedef int dword_1099D620_t[];
#define dword_1099D620 XI_EA(dword_1099D620_t, 0x1099D620u)
typedef int dword_1099D624_t[];
#define dword_1099D624 XI_EA(dword_1099D624_t, 0x1099D624u)
typedef int dword_1099D628_t[];
#define dword_1099D628 XI_EA(dword_1099D628_t, 0x1099D628u)
typedef int dword_1099D62C_t[];
#define dword_1099D62C XI_EA(dword_1099D62C_t, 0x1099D62Cu)
typedef int dword_1099D630_t[];
#define dword_1099D630 XI_EA(dword_1099D630_t, 0x1099D630u)
typedef int dword_1099D634_t[];
#define dword_1099D634 XI_EA(dword_1099D634_t, 0x1099D634u)
typedef int dword_1099D638_t[];
#define dword_1099D638 XI_EA(dword_1099D638_t, 0x1099D638u)
typedef int dword_1099D63C_t[5111];
#define dword_1099D63C XI_EA(dword_1099D63C_t, 0x1099D63Cu)
typedef int dword_109A2618_t;
#define dword_109A2618 XI_EA(dword_109A2618_t, 0x109A2618u)
typedef int dword_109A261C_t;
#define g_counter_109A261C XI_EA(dword_109A261C_t, 0x109A261Cu)
typedef char byte_109A2620_t[256];
#define byte_109A2620 XI_EA(byte_109A2620_t, 0x109A2620u)
typedef int dword_109A2730_t;
#define dword_109A2730 XI_EA(dword_109A2730_t, 0x109A2730u)
typedef int dword_109A2744_t;
#define g_counter_109A2744 XI_EA(dword_109A2744_t, 0x109A2744u)
typedef int dword_109A2798_t[];
#define g_sceneRT XI_EA(dword_109A2798_t, 0x109A2798u)
typedef int dword_109A279C_t;
#define g_sceneRT1 XI_EA(dword_109A279C_t, 0x109A279Cu)
typedef char byte_109F81A4_t;
#define byte_109F81A4 XI_EA(byte_109F81A4_t, 0x109F81A4u)
typedef _BYTE g_pCameraSharedInstance_t;
#define g_pCameraSharedInstance XI_EA(g_pCameraSharedInstance_t, 0x109F81C0u)
